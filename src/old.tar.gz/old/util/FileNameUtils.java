package old.util;

import java.io.File;

import old.main.DistFragsConstants;


public class FileNameUtils implements DistFragsConstants
{
	public static File[] getLazarInputFiles(String dataset, boolean open)
	{
		File classFile = new File("/home/martin/data/cpdb/" + dataset + "/data/" + dataset + ".class");
		File smilesFile = new File("/home/martin/data/cpdb/" + dataset + "/data/" + dataset + ".smi");
		File linfragFile;
		if (!open)
			linfragFile = new File("/home/martin/data/cpdb/" + dataset + "/data/" + dataset + ".linfrag");
		else
			linfragFile = new File("/home/martin/results/distance/linfrag/" + dataset + ".open.linfrag");

		File f[] = new File[] { classFile, smilesFile, linfragFile };
		return f;
	}

	// public static String[] getDistFragParams(boolean printToFile)
	// {
	// String[] args = new String[] { "-t",
	// // "/home/martin/results/selection/data/5fold/" + endpoint + "/train/" + endpoint + ".class.fold1.train",
	// "/home/martin/data/cpdb/" + DistFrags.DATASET + "/data/" + DistFrags.DATASET + ".class", "-s",
	// // "/home/martin/results/selection/data/5fold/" + endpoint + "/train/" + endpoint + ".smi.fold1.train",
	// "/home/martin/data/cpdb/" + DistFrags.DATASET + "/data/" + DistFrags.DATASET + ".smi", "-f",
	// // "/home/martin/results/selection/linfrag/" + featureType + "/" + endpoint + "/" + endpoint + "-" + featureType
	// // + "-fold1.linfrag",
	// "/home/martin/data/cpdb/" + DistFrags.DATASET + "/data/" + DistFrags.DATASET + ".linfrag",
	// /* "-v", */"-l", printToFile ? "-o" : "", printToFile ? getDistFragsOutfile() : "" };
	// return args;
	// }

	public static String getDistFragsOutfile(String dataset)// String endpoint, String featureType)
	{
		String baseDir = "/home/martin/results/distance/dist/";

		return baseDir + dataset + "." + VERSION + ".dist";
	}

	public static String getDistFragsArffFile(String dataset, boolean open)
	{
		String baseDir = "/home/martin/results/distance/arff/";

		return baseDir + dataset + (open ? ".open" : "") + "." + VERSION + ".arff";
	}

	public static String getInputArffFile(String dataset, boolean open)
	{
		String baseDir = "/home/martin/results/distance/arff/";

		return baseDir + dataset + (open ? ".open" : "") + ".orig.arff";
	}

}
