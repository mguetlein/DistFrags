package old.util;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;

import weka.classifiers.Evaluation;
import weka.classifiers.trees.J48;
import weka.core.Instances;

public class WekaArffEval
{
	public static void main(String args[])
	{
		// String dataset = "hamster_carcinogenicity";
		// String dataset = "hamster_female_carcinogenicity";
		// String dataset = "hamster_male_carcinogenicity";
		// String dataset = "mouse_carcinogenicity";http://www.google.de/
		// String dataset = "mouse_female_carcinogenicity";
		// String dataset = "mouse_male_carcinogenicity";
		// String dataset = "multi_cell_call";
		// String dataset = "rat_carcinogenicity";
		// String dataset = "single_cell_call";
		String dataset = "salmonella_mutagenicity";

		// new WekaArffEval(FileNameUtils.getInputArffFile(dataset, false));
		new WekaArffEval(FileNameUtils.getDistFragsArffFile(dataset, false));
	}

	public WekaArffEval(String arffFile)
	{
		try
		{
			PrintStreams.STATUS_INFO.println("reading arff file: " + arffFile);
			Instances data = new Instances(new BufferedReader(new FileReader(arffFile)));
			PrintStreams.STATUS_INFO.println("instances: " + data.numInstances());
			PrintStreams.STATUS_INFO.println("attributes: " + data.numAttributes());
			data.setClassIndex(data.numAttributes() - 1);

			// PrintStreams.STATUS_INFO.println("building classifier");

			J48 clazzy = new J48();
			clazzy.setUnpruned(true);

			// NaiveBayes clazzy = new NaiveBayes();

			// SMO clazzy = new SMO();

			PrintStreams.STATUS_INFO.println("Starting 10 fold");
			Evaluation eval = new Evaluation(data);
			eval.crossValidateModel(clazzy, data, 10, new Random(1));

			PrintStreams.STATUS_INFO.println(eval.toSummaryString());

		}
		catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
