package old.util;

import java.io.OutputStream;
import java.io.PrintStream;

public class PrintStreams
{
	public static PrintStream NULL_PRINT_STREAM = new PrintStream(new OutputStream()
	{
		public void write(int b)
		{}
	});

	public static PrintStream OUT = System.out;

	public static PrintStream WARNING = NULL_PRINT_STREAM;// System.err;

	public static PrintStream VERBOSE = NULL_PRINT_STREAM;

	public static PrintStream STATUS_INFO = System.out;

	static
	{
		// System.setOut(NULL_PRINT_STREAM);
	}

	public static boolean isVerbose()
	{
		return VERBOSE != NULL_PRINT_STREAM;
	}

	public static void setVerbose(boolean b)
	{
		if (b)
			VERBOSE = System.err;
		else
			VERBOSE = NULL_PRINT_STREAM;
	}

}
