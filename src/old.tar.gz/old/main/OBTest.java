package old.main;

import java.io.OutputStream;
import java.io.PrintStream;
import java.util.HashMap;

import org.openbabel.OBAtom;
import org.openbabel.OBBond;
import org.openbabel.OBConversion;
import org.openbabel.OBMol;
import org.openbabel.OBMolAtomBFSIter;
import org.openbabel.OBMolAtomIter;
import org.openbabel.OBSmartsPattern;
import org.openbabel.SWIGTYPE_p_std__vectorT_OpenBabel__OBAtom_p_t__iterator;
import org.openbabel.vectorInt;
import org.openbabel.vvInt;

public class OBTest
{
	public OBTest()
	{
		System.loadLibrary("openbabel");
		System.setErr(new PrintStream(new OutputStream()
		{
			public void write(int b)
			{}
		}));
	}

	public void run()
	{
		OBConversion c = new OBConversion();
		OBMol mol = new OBMol();

		String smiles = "OCC";
		// String inchi = "InChI=1/C6H13NO2/c1-4(2)3-5(7)6(8)9/h4-5H,3,7H2,1-2H3,(H,8,9)/f/h8H";

		c.SetInAndOutFormats("smiles", "inchi");
		c.ReadString(mol, smiles);

		System.out.println("smiles " + smiles);

		System.out.println("'" + c.WriteString(mol) + "'");

		System.out.println("nr atoms '" + mol.NumAtoms() + "'");

		System.out.println("Molecular weight " + mol.GetMolWt());

		// OBFormat inFormat;

		OBSmartsPattern smarts = new OBSmartsPattern();
		smarts.Init("CC");

		// string filename;
		// vector< vector <int> > maplist;
		// vector< vector <int> >::iterator matches;
		// double dihedral, bondLength;
		//
		// for (int i = 1; i < argc; i++)
		// {
		// obMol.Clear();
		// filename = argv[i];
		// inFormat = obConversion.FormatFromExt(filename.c_str());
		// obConversion.SetInFormat(inFormat);
		// obConversion.ReadFile(&obMol, filename);

		HashMap<Integer, HashMap<Integer, Integer>> dist = new HashMap<Integer, HashMap<Integer, Integer>>();

		OBMolAtomIter mIter = new OBMolAtomIter(mol);

		Object o = mIter.BeginData();

		int count = 0;

		SWIGTYPE_p_std__vectorT_OpenBabel__OBAtom_p_t__iterator atomIterator1 = mol.BeginAtoms();
		OBAtom atom1 = mol.BeginAtom(atomIterator1);

		do
		{
			System.out.println(atom1.GetType());
			//			
			//			
			//
			OBMolAtomBFSIter bfsIterator = new OBMolAtomBFSIter(mol, (int) atom1.GetIdx());
			// OBMolAtomDFSIter dfsIterator = new OBMolAtomDFSIter(mol, (int) atom1.GetIdx());

			System.out.println(bfsIterator.GetType());

			for (OBAtom atom : bfsIterator)
			{
				System.out.println("- distance to atom " + atom.GetType() + ": " + atom.GetCurrentDepth() + " "
						+ bfsIterator.CurrentDepth());
			}

			// SWIGTYPE_p_std__vectorT_OpenBabel__OBAtom_p_t__iterator atomIterator2 = mol.BeginAtoms();
			//
			// OBAtom nAtom = bfsIterator.GetNextAtom();
			//
			// do
			// {
			// System.out.println("- " + nAtom.GetType() + " " + bfsIterator.CurrentDepth());
			//
			// }
			// while ((nAtom = bfsIterator.NextNbrAtom(atomIterator2)) != null);

			// OBAtom b = mol.NextAtom( iter.EndData());

			// SWIGTYPE_p_int intPtr = iter.

			// do
			// {
			// HashMap<Integer, Integer> map = dist.get((int) atom.GetIdx());
			// if (map == null)
			// map = new HashMap<Integer, Integer>();
			// map.put((int) iter.GetIdx(), iter.CurrentDepth() - 1);
			// dist.put((int) atom.GetIdx(), map);
			// }
			// while ((iter = new OBMolAtomBFSIter(iter)) != null);

			count++;

		}
		while ((atom1 = mol.NextAtom(atomIterator1)) != null);

		System.out.println("count " + count);

		if (true == true)
			return;

		OBBond bond;

		if (smarts.Match(mol))
		{
			double dihedral = 0.0;
			double bondLength = 0.0;
			vvInt m = smarts.GetUMapList();

			System.out.println("match " + m);

			for (int i = 0; i < m.size(); i++)
			{
				vectorInt mv = m.get(i);

				OBAtom a = mol.GetAtom(mv.get(0));
				System.out.println("1 " + a.GetType() + " " + a.GetCIdx());

				a = mol.GetAtom(mv.get(1));
				System.out.println("2 " + a.GetType() + " " + a.GetCIdx());

				// a = mol.GetAtom(mv.get(2));
				// System.out.println("3 " + a.GetType() + " " + a.GetCIdx());
				//
				// a = mol.GetAtom(mv.get(3));
				// System.out.println("4 " + a.GetType() + " " + a.GetCIdx());

				System.out.println("");

				// bond = mol.GetBond(mv.get(0), mv.get(1));
				// System.out.println(mv);
				// System.out.println("begin " + bond.GetBeginAtom().GetType() + " " + bond.GetBeginAtom().GetX() + "/"
				// + bond.GetBeginAtom().GetY() + "/" + bond.GetBeginAtom().GetZ());
				// System.out.println("end " + bond.GetEndAtom().GetType() + " " + bond.GetEndAtom().GetX() + "/"
				// + bond.GetEndAtom().GetY() + "/" + bond.GetEndAtom().GetZ());
				// System.out.println("bond length " + bond.GetLength());
			}

			// for (matches = maplist.begin(); matches != maplist.end(); matches++)
			// {
			// dihedral += fabs(obMol.GetTorsion((*matches)[0],
			// (*matches)[1],
			// (*matches)[2],
			// (*matches)[3]));
			// b1 = obMol.GetBond((*matches)[1], (*matches)[2]);
			// bondLength += b1->GetLength();
			// }
			// cout << filename << ": Average Dihedral " << dihedral / maplist.size()
			// << " Average Bond Length " << bondLength / maplist.size()
			// << " over " << maplist.size() << " matches\n";
		}
		else
			System.out.println("no match");
		// }

	}

	public static void main(String[] args)
	{
		System.out.println("Running OBTest...");

		OBTest test = new OBTest();

		test.run();
	}
}
