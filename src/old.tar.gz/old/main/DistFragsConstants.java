package old.main;

public interface DistFragsConstants
{
	public static String TAB = "  ";

	public static String VERSION = "distfrag_v3";

	// v2 -> 10, 4

	// v1 -> 6, 3

	public static int MIN_NUM_COMMON_MOLECULES = 6;

	public static int MIN_NUM_COMMON_MOLECULES_FOR_EACH_CLASS = 3;
}
