package old.main;

import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

import old.util.FileNameUtils;
import old.util.PrintStreams;


public class InputArffGenerator
{
	InputData data;

	static PrintStream ARFF = System.out;

	public static void main(String args[])
	{
		// String dataset = "hamster_carcinogenicity";
		// DistFrags.DATASET = "hamster_female_carcinogenicity";
		// DistFrags.DATASET = "hamster_male_carcinogenicity";
		// String dataset = "mouse_carcinogenicity";
		// DistFrags.DATASET = "mouse_female_carcinogenicity";
		// DistFrags.DATASET = "mouse_male_carcinogenicity";
		// DistFrags.DATASET = "multi_cell_call";
		// DistFrags.DATASET = "rat_carcinogenicity";

		String cpdb[] = new String[] { "hamster_carcinogenicity", "hamster_female_carcinogenicity",
				"hamster_male_carcinogenicity", "mouse_carcinogenicity", "mouse_female_carcinogenicity",
				"mouse_male_carcinogenicity", "multi_cell_call", "rat_carcinogenicity", "rat_female_carcinogenicity",
				"rat_male_carcinogenicity", "salmonella_mutagenicity", "single_cell_call" };

		// int count = 0;

		for (String d : cpdb)
		{
			try
			{
				String out = FileNameUtils.getInputArffFile(d, true);
				ARFF = new PrintStream(out);
				PrintStreams.STATUS_INFO.println("arff-out-file: " + out);
			}
			catch (FileNotFoundException e)
			{
				e.printStackTrace();
			}

			new InputArffGenerator(d);
		}
	}

	public InputArffGenerator(String dataset)
	{
		data = LazarInputData.getLazarInputData(dataset, true);

		ARFF.println("% generated: " + new SimpleDateFormat("yyyy.MM.dd HH:mm:ss").format(new Date()));
		ARFF.println("% num molecules: " + data.getMoleculeIds().size());
		ARFF.println("% num features: " + data.getFeatures().size());
		ARFF.println();
		ARFF.println("@relation \"" + data.getDatasetName() + " distance-fragments\"");
		ARFF.println();

		for (int i = 0; i < data.getFeatures().size(); i++)
		{
			ARFF.println("@attribute " + data.getEscapedFeature(i) + " {0,1}");
		}
		ARFF.println("@attribute " + data.getFirstEndpoint() + " {0,1}");
		ARFF.println();

		ARFF.println("@data");

		for (Integer moleculeId : data.moleculeIds)
		{
			ARFF.print("{");
			boolean first = true;

			Vector<Integer> features = data.getFeaturesForMolecule(moleculeId);
			if (features != null)
			{
				for (int i = 0; i < features.size(); i++)
				{
					if (!first)
						ARFF.print(", ");
					else
						first = false;
					ARFF.print(features.get(i) + " 1");
				}
			}
			if (!first)
				ARFF.print(", ");
			ARFF.print(data.getFeatures().size() + " " + data.getFirstEndpointClassValue(moleculeId));
			ARFF.println("}");
		}

	}
}
