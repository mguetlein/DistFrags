package old.main;

import java.util.HashMap;
import java.util.Vector;

import old.util.PrintStreams;


public abstract class InputData implements DistFragsConstants
{
	protected String datasetName;

	/**
	 * molecule ids, INDEX is used if features-occurences are stored as line number
	 */
	protected Vector<Integer> moleculeIds = new Vector<Integer>();

	/**
	 * all occurring endpoints
	 */
	protected Vector<String> endpoints = new Vector<String>();

	/**
	 * key: molecule-id<br>
	 * value: smiles-string
	 */
	protected HashMap<Integer, String> smiles = new HashMap<Integer, String>();

	/**
	 * key: molecule-id<br>
	 * value: inchi-string
	 */
	// protected HashMap<Integer, String> inchis = new HashMap<Integer, String>();
	/**
	 * key: molecule-id_endpoint<br>
	 * value: class-value
	 */
	protected HashMap<String, Integer> classValues = new HashMap<String, Integer>();

	/**
	 * features as string, INDEX is used in featureToMolecues and moleculesToFeatures
	 */
	protected Vector<String> features = new Vector<String>();

	/**
	 * key: feature-INDEX<br>
	 * value: vector with molecule-ids
	 */
	protected HashMap<Integer, Vector<Integer>> featureToMolecules = new HashMap<Integer, Vector<Integer>>();

	/**
	 * key: modelcule-id<br>
	 * value: vector with feature-INDICES
	 */
	protected HashMap<Integer, Vector<Integer>> moleculesToFeatures = new HashMap<Integer, Vector<Integer>>();

	public Vector<Integer> getMoleculeIds()
	{
		return moleculeIds;
	}

	public Vector<Integer> getFeaturesForMolecule(int moleculeId)
	{
		return moleculesToFeatures.get(moleculeId);
	}

	public Vector<Integer> getMoleculesForFeature(int featureIndex)
	{
		return featureToMolecules.get(featureIndex);
	}

	public Vector<String> getFeatures()
	{
		return features;
	}

	public String getFeature(int index)
	{
		return features.get(index);
	}

	public String getEscapedFeature(int index)
	{
		return features.get(index).replace("\\", "\\\\");
	}

	public String getSmiles(int id)
	{
		String s = smiles.get(id);

		if (s == null)
		{
			assert false : "no smiles found for " + id;
			return null;
		}
		return s;
	}

	public String getEscapedSmiles(int moleculeId)
	{
		return getSmiles(moleculeId).replace("\\", "\\\\");
	}

	public int getFirstEndpointClassValue(int id)
	{
		Integer act = classValues.get(getClassValueKey(id, endpoints.firstElement()));
		if (act == null)
		{
			assert false : "no class value found for " + id + " endpoint: " + endpoints.firstElement();
			return -1;
		}
		else
			return act;
	}

	public String getFirstEndpoint()
	{
		return endpoints.firstElement();
	}

	public int getClassValue(int id, String endpoint)
	{
		Integer act = classValues.get(getClassValueKey(id, endpoint));
		// System.out.println("reading act from db " + getKey(id, endpoint) + " " + act);
		if (act == null)
		{
			assert false : "no class value found for " + id + " endpoint: " + endpoint;
			return -1;
		}
		else
			return act;
	}

	protected String getClassValueKey(int id, String endpoint)
	{
		return id + "_" + endpoint;
	}

	public String getDatasetName()
	{
		return datasetName;
	}

	public void printInfo()
	{
		PrintStreams.OUT.println("input-data:");
		printInputInfo();
		PrintStreams.OUT.println("" + TAB + "num-molecules:" + TAB + "" + moleculeIds.size());
		PrintStreams.OUT.println("" + TAB + "endpoints:");
		for (String endpoint : endpoints)
		{
			PrintStreams.OUT.println("" + TAB + "" + TAB + "- name:" + TAB + "" + endpoint);

			int num_activity_one = 0;
			for (int id : moleculeIds)
				if (getClassValue(id, endpoint) == 1)
					num_activity_one++;

			PrintStreams.OUT.println("" + TAB + "" + TAB + "  activity-equals-1:" + TAB + "" + num_activity_one);
			PrintStreams.OUT.println();
		}
		PrintStreams.OUT.println("" + TAB + "num-features:" + TAB + "" + features.size());

		double avgNumMoleculesPerFeature = 0;
		for (int i = 0; i < features.size(); i++)
		{
			avgNumMoleculesPerFeature = (avgNumMoleculesPerFeature * i + featureToMolecules.get(i).size())
					/ (double) (i + 1);
		}
		PrintStreams.OUT.printf("" + TAB + "num-molecules-per-feature:" + TAB + "%.1f\n", avgNumMoleculesPerFeature);

		double avgNumFeaturesPerMolecule = 0;
		for (int i = 0; i < moleculeIds.size(); i++)
		{
			Vector<Integer> features = moleculesToFeatures.get(moleculeIds.get(i));
			int num = features == null ? 0 : features.size();
			avgNumFeaturesPerMolecule = (avgNumFeaturesPerMolecule * i + num) / (double) (i + 1);
		}
		PrintStreams.OUT.printf("" + TAB + "num-features-per-molecule:" + TAB + "%.1f\n", avgNumFeaturesPerMolecule);
		PrintStreams.OUT.println();

	}

	protected abstract void printInputInfo();
}
