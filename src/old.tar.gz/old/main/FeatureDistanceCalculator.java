package old.main;

import gui.ProgressDialog;
import io.Status;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.swing.JFrame;

import launch.Settings;
import old.util.FileNameUtils;
import old.util.PrintStreams;

import org._3pq.jgrapht.UndirectedGraph;
import org._3pq.jgrapht.alg.DijkstraShortestPath;
import org.openscience.cdk.DefaultChemObjectBuilder;
import org.openscience.cdk.exception.CDKException;
import org.openscience.cdk.graph.MoleculeGraphs;
import org.openscience.cdk.interfaces.IAtom;
import org.openscience.cdk.interfaces.IAtomContainer;
import org.openscience.cdk.interfaces.IMolecule;
import org.openscience.cdk.isomorphism.UniversalIsomorphismTester;
import org.openscience.cdk.isomorphism.mcss.RMap;
import org.openscience.cdk.smiles.SmilesParser;

import util.StringUtil;
import util.VectorUtil;

public class FeatureDistanceCalculator implements DistFragsConstants
{
	public PrintStream FEATURE_INFO;
	public PrintStream MOLECULE_INFO;
	public PrintStream OCCURENCE_INFO;

	public static PrintStream WARNING = PrintStreams.WARNING;

	int skipFeaturesAtomCountLessThree = 0;
	int skipFeaturesTooMuchOverlap = 0;
	int skipFeaturesOnlyC = 0;
	int skipFeaturesNoSubstructure = 0;
	int skipFeaturesNoPath = 0;

	int numFeaturePairs = 0;
	double avgNoSubstructureOfMoleculeCount = 0;
	double avgNumCommonMolecules = 0;
	double overallAvgOccurencePairs = 0;
	double overallOverlapPerPairRatio = 0;
	double overallNoPathPerFeaturePairRatio = 0;
	double overallAvgDistanceActive = 0;
	double overallAvgDistanceInactive = 0;

	Map<Integer, IMolecule> moleculeMap = new HashMap<Integer, IMolecule>();
	Map<Integer, IMolecule> featureMap = new HashMap<Integer, IMolecule>();

	InputData data;

	public static void main(String args[])
	{
		String dataset = "hamster_carcinogenicity";
		// dataset = "hamster_female_carcinogenicity";
		// dataset = "hamster_male_carcinogenicity";
		// dataset = "mouse_carcinogenicity";
		// dataset = "mouse_female_carcinogenicity";
		// dataset = "mouse_male_carcinogenicity";
		// dataset = "multi_cell_call";
		// dataset = "rat_carcinogenicity";

		new FeatureDistanceCalculator(dataset);
	}

	public FeatureDistanceCalculator(String dataset)
	{
		Date starttime = new Date();

		boolean contineExistingFile = false;
		int continueFeature1 = -1;
		int continueFeature2 = -1;

		String outFile = FileNameUtils.getDistFragsOutfile(dataset);
		if (outFile != null)
		{
			try
			{
				File f = new File(outFile);
				if (f.exists())
				{
					DistFragsContinue cont = new DistFragsContinue(f);
					if (cont.isContinueOK())
					{
						PrintStreams.STATUS_INFO.println("> Continuing file: " + f);

						contineExistingFile = true;
						continueFeature1 = cont.getFeature1();
						continueFeature2 = cont.getFeature2();

						PrintStreams.OUT = new PrintStream(new FileOutputStream(f, true));
					}
					else
					{
						if (cont.isAlreadyFinished())
						{
							System.err.println("Out-file already finsihed '" + outFile + "'");
							return;
						}
						else
						{
							System.err.println("Out-file already exists and cannot be continued '" + outFile + "'");
							System.exit(1);
						}
					}
				}
				else
					PrintStreams.OUT = new PrintStream(outFile);

				PrintStreams.STATUS_INFO.println("Printing output to file: '" + outFile + "'");
			}
			catch (FileNotFoundException e)
			{
				e.printStackTrace();
				System.exit(1);
			}
		}

		if (!contineExistingFile)
		{
			PrintStreams.OUT.println("---");
			PrintStreams.OUT.println("start-time: " + new SimpleDateFormat("yyyy.MM.dd HH:mm:ss").format(starttime));
			PrintStreams.OUT.println();

			// OUT.println("parameters:");
			// OUT.println(" " + TAB + "class-file:" + TAB + "" + classFile.firstElement());
			// OUT.println(" " + TAB + "smiles-file:" + TAB + "" + smilesFile.firstElement());
			// OUT.println(" " + TAB + "feature-file:" + TAB + "" + featureFile.firstElement());
			// OUT.println(" " + TAB + "verbose:" + TAB + "true");
			// OUT.println(" " + TAB + "out-file:" + TAB + "" + outFile);
			// OUT.println(" " + TAB + "lines-in-feature-file:" + TAB + linesInFeatureFile);
			// OUT.println();
		}

		InputData data = LazarInputData.getLazarInputData(dataset, false);

		if (!contineExistingFile)
			data.printInfo();

		FEATURE_INFO = PrintStreams.OUT;
		MOLECULE_INFO = PrintStreams.OUT;
		OCCURENCE_INFO = PrintStreams.NULL_PRINT_STREAM;// PrintStreams.OUT;

		this.data = data;

		checkAllFeaturePairs(continueFeature1, continueFeature2);

		// int i = 4;
		// int j = 443;
		// Vector<Integer> molecules1 = data.getMoleculesForFeature(i);
		// Vector<Integer> molecules2 = data.getMoleculesForFeature(j);
		//
		// Vector<Integer> molecules = (Vector<Integer>) VectorUtil.cut(molecules1, molecules2);
		// if (molecules.size() >= MIN_NUM_COMMON_MOLECULES)
		// {
		// int numActive = 0;
		// for (Integer id : molecules)
		// if (data.getFirstEndpointClassValue(id) == 1)
		// numActive++;
		// int numInactive = molecules.size() - numActive;
		//
		// if (numActive >= MIN_NUM_COMMON_MOLECULES_FOR_EACH_CLASS
		// && numInactive >= MIN_NUM_COMMON_MOLECULES_FOR_EACH_CLASS)
		// {
		// getFeatureDistance(i, j, molecules);
		// }
		// }

		// -------------------------------

		// int x = 70;
		// CoOccurenceMiner coOcc = new CoOccurenceMiner(data);
		// for (int i = 0; i < coOcc.getNumMarkedCoOcurrences(); i++)
		// {
		// int occ[] = coOcc.getMarkedCoOccurence(i);
		//
		// // if (i < x)
		// // continue;
		// // if (occ[0] != 40 || occ[1] != 39)
		// // continue;
		// getFeatureDistance(occ[0], occ[1]);
		// // if (i > x + 20)
		// // break;
		// }

		// int i = 3;
		// int j = 17;
		//
		// Vector<Integer> molecules1 = data.getMoleculesForFeature(i);
		// Vector<Integer> molecules2 = data.getMoleculesForFeature(j);
		//
		// Vector<Integer> molecules = (Vector<Integer>) VectorUtil.cut(molecules1, molecules2);
		// if (molecules.size() > 0)
		// getFeatureDistance(i, j, molecules);

		// double avgTotalFeatureOccurences = numTotalFeatureOccurences / (double) (numFeaturePairs * 2);
		// double avgSingleFeatureOccurence = numSingleFeatureOccurence / (double) (numFeaturePairs * 2);
		// double avgOverlap = numOverlap / (double) numFeaturePairs;
		//
		// PrintStreams.OUT.println("distance-summary:");
		// PrintStreams.OUT.printf(""+TAB+"Omitted Pairs:"+TAB+"%d + %d (Atom-Count < 3 + no match)\n",
		// numAtomCountSmallerThree,
		// numFeatureNotFound);
		// PrintStreams.OUT.printf(""+TAB+"Pairs left:"+TAB+"%d\n", numFeaturePairs);
		// PrintStreams.OUT.printf(""+TAB+"Avg Occurences:"+TAB+"%.2f (%d)\n", avgTotalFeatureOccurences,
		// numTotalFeatureOccurences);
		// PrintStreams.OUT.printf(""+TAB+"Single Occurence Ratio:"+TAB+"%.2f (%d)\n", avgSingleFeatureOccurence,
		// numSingleFeatureOccurence);
		// PrintStreams.OUT.printf(""+TAB+"Overlap Ratio:"+TAB+"%.2f (%d)\n", avgOverlap, numOverlap);
		// PrintStreams.OUT.println();

		PrintStreams.OUT.println("distance-summary:");
		// PrintStreams.OUT.printf(""+TAB+"omitted-pairs-<-3-atoms:"+TAB+"%d\n", skipFeaturesAtomCountLessThree);
		PrintStreams.OUT.printf("" + TAB + "omitted-pairs-overlap:" + TAB + "%d\n", skipFeaturesTooMuchOverlap);
		PrintStreams.OUT.printf("" + TAB + "omitted-pairs-only-C:" + TAB + "%d\n", skipFeaturesOnlyC);
		PrintStreams.OUT.printf("" + TAB + "omitted-pairs-no-substructures:" + TAB + "%d\n", skipFeaturesNoSubstructure);
		PrintStreams.OUT.printf("" + TAB + "omitted-pairs-no-path:" + TAB + "%d\n", skipFeaturesNoPath);
		PrintStreams.OUT.printf("" + TAB + "feature-pairs:" + TAB + "%d\n", numFeaturePairs);
		PrintStreams.OUT.println("" + TAB + "avg-num-no-substructure-of-molecule:" + TAB + ""
				+ avgNoSubstructureOfMoleculeCount);
		PrintStreams.OUT.println("" + TAB + "avg-num-common-molecules:" + TAB + "" + avgNumCommonMolecules);
		PrintStreams.OUT.println("" + TAB + "avg-num-occurence-pairs:" + TAB + "" + overallAvgOccurencePairs);
		PrintStreams.OUT.println("" + TAB + "avg-overlap-per-pair-ratio:" + TAB + "" + overallOverlapPerPairRatio);
		PrintStreams.OUT.println("" + TAB + "avg-no-path-per-feature-pair-ratio:" + TAB + ""
				+ overallNoPathPerFeaturePairRatio);
		PrintStreams.OUT.println("" + TAB + "avg-distance-active:" + TAB + "" + overallAvgDistanceActive);
		PrintStreams.OUT.println("" + TAB + "avg-distance-inactive:" + TAB + "" + overallAvgDistanceInactive);
		PrintStreams.OUT.println();

		Date endtime = new Date();

		PrintStreams.OUT.println("continued: " + (continueFeature1 != -1));
		PrintStreams.OUT.println("continued-feature1: " + continueFeature1);
		PrintStreams.OUT.println("continued-feature2: " + continueFeature2);
		PrintStreams.OUT.println("end-time: " + new SimpleDateFormat("yyyy.MM.dd HH:mm:ss").format(endtime));
		PrintStreams.OUT.println("run-time: " + StringUtil.formatTime(endtime.getTime() - starttime.getTime()));
		PrintStreams.OUT.println("...");
	}

	@SuppressWarnings("unchecked")
	private void checkAllFeaturePairs(int startFeature1, int startFeature2)
	{
		int numAlreadyCalculated;

		if (startFeature1 < 0 || startFeature2 < 0)
		{
			FEATURE_INFO.println("distance-pairs:");
			startFeature1 = 0;
			startFeature2 = 0;
			numAlreadyCalculated = 0;
		}
		else
		{
			// 1: * * * * * * * * * * * * * * * * -
			// 1: * * * * * * * * * * * * * * * - -
			// 1: * * * * * * * * * * * * * * - - -
			// 1: * * * * * * * * * * * * * - - - -
			// 1: * * * * * * * * * * * * - - - - -
			// 1: * * * * * * * * * * * - - - - - -
			// 1: * * * * * * * * * * - - - - - - -
			// 1: * * * * * * * * * - - - - - - - -
			// 2: * * * o o o o - - - - - - - - - -
			// -: o o o o o o - - - - - - - - - - -
			// -: o o o o o - - - - - - - - - - - -
			// -: o o o o - - - - - - - - - - - - -
			// -: o o o - - - - - - - - - - - - - -
			// -: o o - - - - - - - - - - - - - - -
			// -: o - - - - - - - - - - - - - - - -
			// -: - - - - - - - - - - - - - - - - -

			// * already calculated
			// o not yet calculated
			// - not to be calculated
			// startFeature1 and startFeature2 correspond to the first o

			// 1:
			numAlreadyCalculated = data.getFeatures().size() * (startFeature1 - 1);
			numAlreadyCalculated -= (startFeature1 * (startFeature1 - 1)) / 2;

			// 2:
			numAlreadyCalculated += startFeature2;

			PrintStreams.STATUS_INFO.println("> Continuating at " + startFeature1 + " / " + startFeature2);
			PrintStreams.STATUS_INFO.println("> already calculated " + numAlreadyCalculated);
		}
		int numPairs = (data.getFeatures().size() * (data.getFeatures().size() - 1)) / 2;
		numPairs -= numAlreadyCalculated;

		int pairCount = 0;

		// ProgressDialog progress = new ProgressDialog(null, data.getDatasetName(), numPairs, getProgressInfo(startFeature1,
		// startFeature2, data.getFeatures().size(), pairCount, numPairs));
		// progress.setVisible(true);

		ProgressDialog progress = ProgressDialog.showProgress(Settings.SHOW_PROGRESS_DIALOGS ? (JFrame) null
				: Status.INFO, data.getDatasetName(), numPairs, getProgressInfo(startFeature1, startFeature2, data
				.getFeatures().size(), pairCount, numPairs));

		for (int i = startFeature1; i < data.getFeatures().size() - 1; i++)
		{
			for (int j = i + 1; j < data.getFeatures().size(); j++)
			{
				if (i == startFeature1 && j < startFeature2)
					continue;

				if (j != i)
				{
					Vector<Integer> molecules1 = data.getMoleculesForFeature(i);
					Vector<Integer> molecules2 = data.getMoleculesForFeature(j);

					Vector<Integer> molecules = (Vector<Integer>) VectorUtil.cut(molecules1, molecules2);
					if (molecules.size() >= MIN_NUM_COMMON_MOLECULES)
					{
						int numActive = 0;
						for (Integer id : molecules)
							if (data.getFirstEndpointClassValue(id) == 1)
								numActive++;
						int numInactive = molecules.size() - numActive;

						if (numActive >= MIN_NUM_COMMON_MOLECULES_FOR_EACH_CLASS
								&& numInactive >= MIN_NUM_COMMON_MOLECULES_FOR_EACH_CLASS)
						{
							getFeatureDistance(i, j, molecules);
						}
					}
				}

				pairCount++;

				if (pairCount % 500 == 0)
					progress.update(pairCount, getProgressInfo(i, j, data.getFeatures().size(), pairCount, numPairs));
				// PrintStreams.STATUS_INFO.println(getProgressInfo());

			}
		}

		// PrintStreams.STATUS_INFO.println(getProgressInfo());
		progress.close(pairCount, "done");

		FEATURE_INFO.println();
	}

	private String getProgressInfo(int feature1, int feature2, int numFeatures, int pairCount, int numPairs)
	{
		// return "Done: " + StringUtil.formatDouble(percentPairsDone) + " (" + pairCount + "/" + numPairs + ")";

		// StringBuffer b = new StringBuffer();
		// Formatter f = new Formatter(b);
		// f.format("Done:  current feature %6d, %10d / %10d", feature1, pairCount, numPairs);
		// return b.toString();

		return "Feature1: " + feature1 + "/" + numFeatures + " - Pairs: " + pairCount + "/" + numPairs;
	}

	class FeaturePairInfo
	{
		int feature1;
		int feature2;
		boolean skipCOnly;
		// List<Integer> overlapAtomCount = new ArrayList<Integer>();
		int featureOverlap;
		boolean featureOverlapTooBig;
		List<MoleculeInfo> molecules = new ArrayList<MoleculeInfo>();
		int noSubstructureOfMoleculeCount;
		int molCount;
		double avgNumPairs;
		double overlapPerPairRatio;
		double overallDistanceActive;
		double overallDistanceInactive;

		public boolean isWorthPrinting()
		{
			if (molecules.size() < MIN_NUM_COMMON_MOLECULES)
				return false;

			int numActive = 0;
			for (MoleculeInfo m : molecules)
				if (data.getFirstEndpointClassValue(m.moleculeId) == 1)
					numActive++;
			int numInactive = molecules.size() - numActive;

			return (numActive >= MIN_NUM_COMMON_MOLECULES_FOR_EACH_CLASS && numInactive >= MIN_NUM_COMMON_MOLECULES_FOR_EACH_CLASS);
		}

		public void print()
		{
			if (!isWorthPrinting())
				return;

			FEATURE_INFO.println("" + TAB + "- feature-1-index:" + TAB + "" + feature1);
			FEATURE_INFO.println("" + TAB + "  feature-1-smiles:" + TAB + "\"" + data.getEscapedFeature(feature1) + "\"");
			FEATURE_INFO.println("" + TAB + "  feature-2-index:" + TAB + "" + feature2);
			FEATURE_INFO.println("" + TAB + "  feature-2-smiles:" + TAB + "\"" + data.getEscapedFeature(feature2) + "\"");

			FEATURE_INFO.println("" + TAB + "  skip-pair-only-C:" + TAB + "" + skipCOnly);
			FEATURE_INFO.println("" + TAB + "  feature-overlap:" + TAB + "" + featureOverlap);
			FEATURE_INFO.println("" + TAB + "  too-much-feature-overlap:" + TAB + "" + featureOverlapTooBig);

			MOLECULE_INFO.println("" + TAB + "  common-molecules:");
			for (MoleculeInfo m : molecules)
				m.print();

			FEATURE_INFO.println("" + TAB + "  num-no-substructure-of-molecule:" + TAB + "" + noSubstructureOfMoleculeCount);
			FEATURE_INFO.println("" + TAB + "  num-common-molecules:" + TAB + "" + molCount);
			FEATURE_INFO.println("" + TAB + "  avg-num-occurence-pairs:" + TAB + "" + avgNumPairs);
			FEATURE_INFO.println("" + TAB + "  overlap-per-pair-ratio:" + TAB + "" + overlapPerPairRatio);
			FEATURE_INFO.println("" + TAB + "  distance-active:" + TAB + "" + overallDistanceActive);
			FEATURE_INFO.println("" + TAB + "  distance-inactive:" + TAB + "" + overallDistanceInactive);
			FEATURE_INFO.println();
		}
	}

	class MoleculeInfo
	{
		int moleculeId;
		int feature1occurences;
		int feature2occurences;
		List<OccurenceInfo> occurences = new ArrayList<OccurenceInfo>();
		int noPathCount;
		int occCount;
		int overlapCount;
		double molDistance;

		public void print()
		{
			MOLECULE_INFO.println("" + TAB + "  " + TAB + "- molecule-id:" + TAB + "" + moleculeId);
			MOLECULE_INFO.println("" + TAB + "  " + TAB + "  molecule-smiles:" + TAB + "\""
					+ data.getEscapedSmiles(moleculeId) + "\"");
			MOLECULE_INFO.println("" + TAB + "  " + TAB + "  molecule-activity:" + TAB + ""
					+ data.getFirstEndpointClassValue(moleculeId));

			MOLECULE_INFO.println("" + TAB + "  " + TAB + "  feature-1-num-occurences:" + TAB + "" + feature1occurences);
			MOLECULE_INFO.println("" + TAB + "  " + TAB + "  feature-2-num-occurences:" + TAB + "" + feature2occurences);

			OCCURENCE_INFO.println("" + TAB + "  " + TAB + "  occurence-distances:");
			for (OccurenceInfo o : occurences)
				o.print();

			MOLECULE_INFO.println("" + TAB + "  " + TAB + "  omitted-occurence-no-paths:" + TAB + "" + noPathCount);
			MOLECULE_INFO.println("" + TAB + "  " + TAB + "  num-occurence-pairs:" + TAB + "" + occCount);
			MOLECULE_INFO.println("" + TAB + "  " + TAB + "  num-overlaps:" + TAB + "" + overlapCount);
			MOLECULE_INFO.println("" + TAB + "  " + TAB + "  molecule-distance:" + TAB + "" + molDistance);
			MOLECULE_INFO.println();
		}
	}

	class OccurenceInfo
	{
		int occCount;
		boolean noPath;
		boolean overlap;
		double occDist;

		public void print()
		{
			OCCURENCE_INFO.println("" + TAB + "  " + TAB + "  " + TAB + "- occurence-pair:" + TAB + "" + occCount);
			OCCURENCE_INFO.println("" + TAB + "  " + TAB + "  " + TAB + "  ommitted-occurence-no-path:" + TAB + "" + noPath);
			OCCURENCE_INFO.println("" + TAB + "  " + TAB + "  " + TAB + "  occurence-overlap:" + TAB + "" + overlap);
			OCCURENCE_INFO.printf("" + TAB + "  " + TAB + "  " + TAB + "  occurence-distance:" + TAB + "%f", occDist);
			OCCURENCE_INFO.println();
		}
	}

	@SuppressWarnings("unchecked")
	public double[] getFeatureDistance(int feature1, int feature2, Vector<Integer> moleculeIds)
	{
		IMolecule feat1 = null;
		IMolecule feat2 = null;
		try
		{
			if (featureMap.containsKey(feature1))
				feat1 = featureMap.get(feature1);
			else
			{
				feat1 = new SmilesParser(DefaultChemObjectBuilder.getInstance()).parseSmiles(data.getFeatures()
						.get(feature1));
				featureMap.put(feature1, feat1);
			}
			if (featureMap.containsKey(feature2))
				feat2 = featureMap.get(feature2);
			else
			{
				feat2 = new SmilesParser(DefaultChemObjectBuilder.getInstance()).parseSmiles(data.getFeatures()
						.get(feature2));
				featureMap.put(feature2, feat2);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		// if (feat1.getAtomCount() <= 2 || feat2.getAtomCount() <= 2)
		// {
		// // proceed = false;
		// // WARNING.println("cannot compute distance, atom-count <= 2, " + data.getFeature(feature1) + ", "
		// // + data.getFeature(feature2));
		// // skipFeaturesAtomCountLessThree++;
		// return null;
		// }

		FeaturePairInfo fpInfo = new FeaturePairInfo();
		fpInfo.feature1 = feature1;
		fpInfo.feature2 = feature2;
		// FEATURE_INFO.println("" + TAB + "- feature-1-index:" + TAB + "" + feature1);
		// FEATURE_INFO.println("" + TAB + "  feature-1-smiles:" + TAB + "\"" + data.getEscapedFeature(feature1) + "\"");
		// FEATURE_INFO.println("" + TAB + "  feature-2-index:" + TAB + "" + feature2);
		// FEATURE_INFO.println("" + TAB + "  feature-2-smiles:" + TAB + "\"" + data.getEscapedFeature(feature2) + "\"");

		boolean skipCOnly = false;
		if (!onlyCCheck(feat1))
		{
			WARNING.println("feat 1 is only C, skip pair: " + data.getFeature(feature1));
			skipFeaturesOnlyC++;
			skipCOnly = true;
		}

		if (!skipCOnly && !onlyCCheck(feat2))
		{
			WARNING.println("feat 2 is only C, skip pair: " + data.getFeature(feature2));
			skipFeaturesOnlyC++;
			skipCOnly = true;
		}

		fpInfo.skipCOnly = skipCOnly;
		// FEATURE_INFO.println("" + TAB + "  skip-pair-only-C:" + TAB + "" + skipCOnly);
		// FEATURE_INFO.println("" + TAB + "  overlaps:");

		int featureOverlap = 0;
		boolean tooMuchFeatureOverlap = false;

		if (!skipCOnly)
		{
			// int maxOverlapSize = Math.min(feat1.getAtomCount(), feat2.getAtomCount()) - 1;

			int maxOverlapSize = Math.max(0, Math.min(feat1.getAtomCount(), feat2.getAtomCount()) - 3);
			/*
			 * maxOverlapSize = Math.max(0, Math.min(feat1.getAtomCount(), feat2.getAtomCount()) - 3); means:
			 * 
			 * smaller feature <= 3 atoms -> no overlap allowed
			 * 
			 * smaller feature <= 4 atoms -> max overlap = 1
			 * 
			 * smaller feature <= 5 atoms -> max overlap = 2
			 * 
			 * ...
			 */

			// String f1 = data.getEscapedFeature(feature1);
			// String f2 = data.getEscapedFeature(feature2);
			featureOverlap = getBiggestOverlap(feat1, feat2);
			if (featureOverlap > maxOverlapSize)
			{
				tooMuchFeatureOverlap = true;
				skipFeaturesTooMuchOverlap++;
				WARNING.println("too much overlap, skipping feature pair: " + data.getFeature(feature1) + ", "
						+ data.getFeature(feature2));
			}

			// List<IAtomContainer> overlap = UniversalIsomorphismTester.getOverlaps(feat1, feat2);
			// for (IAtomContainer atomContainer : overlap)
			// {
			// // assert (atomContainer.getAtomCount() > 0);
			//
			// fpInfo.overlapAtomCount.add(atomContainer.getAtomCount());
			// // FEATURE_INFO.println("" + TAB + "    - overlap:" + TAB + "" + atomContainer.getAtomCount());
			//
			// if (atomContainer.getAtomCount() > maxOverlapSize)
			// {
			// featureOverlap = true;
			// skipFeaturesTooMuchOverlap++;
			// WARNING.println("too much overlap, skipping feature pair: " + data.getFeature(feature1) + ", "
			// + data.getFeature(feature2));
			// break;
			// }
			// }

			// FEATURE_INFO.println();
		}

		fpInfo.featureOverlap = featureOverlap;
		fpInfo.featureOverlapTooBig = tooMuchFeatureOverlap;
		// FEATURE_INFO.println("" + TAB + "  too-much-feature-overlap:" + TAB + "" + featureOverlap);

		double overallDistanceActive = 0.0;
		double overallDistanceInactive = 0.0;
		int molCount = 0;
		int molCountActive = 0;
		int molCountInactive = 0;
		double avgNumPairs = 0;
		double overlapPerPairRatio = 0;
		int noPathCount = 0;
		int noSubstructureOfMoleculeCount = 0;

		Vector<Double> activeDistances = new Vector<Double>();
		Vector<Double> inactiveDistances = new Vector<Double>();

		// int overlappCount = 0;

		// MOLECULE_INFO.println("" + TAB + "  common-molecules:");

		if (!skipCOnly && !tooMuchFeatureOverlap)
		{
			boolean noSub = false;
			boolean noPath = false;

			for (Integer moleculeId : moleculeIds)
			{
				String smiles = data.getSmiles(moleculeId);

				try
				{
					IMolecule molecule;
					if (moleculeMap.containsKey(moleculeId))
						molecule = moleculeMap.get(moleculeId);
					else
					{
						molecule = new SmilesParser(DefaultChemObjectBuilder.getInstance()).parseSmiles(smiles);
						assert (molecule.getAtomCount() > 0);
						moleculeMap.put(moleculeId, molecule);
					}

					List<List<RMap>> map1 = null;
					List<List<RMap>> map2 = null;

					map1 = (List<List<RMap>>) UniversalIsomorphismTester.getSubgraphAtomsMaps(molecule, feat1);
					if (map1.size() == 0)
					{
						WARNING.println("cannot compute distance, feature-1 " + data.getFeature(feature1)
								+ " is no subgraph of " + smiles);
						noSubstructureOfMoleculeCount++;
						noSub = true;
						continue;
					}
					assert (map1.get(0) instanceof List);

					map2 = (List<List<RMap>>) UniversalIsomorphismTester.getSubgraphAtomsMaps(molecule, feat2);
					if (map2.size() == 0)
					{
						WARNING.println("cannot compute distance, feature-2 " + data.getFeature(feature2)
								+ " is no subgraph of " + smiles);
						noSubstructureOfMoleculeCount++;
						noSub = true;
						continue;
					}
					if (!(map2.get(0) instanceof List))
					{
						System.err.println("WTF");
						data.getFeature(feature2);
						System.exit(1);
					}

					MoleculeInfo mInfo = new MoleculeInfo();
					mInfo.moleculeId = moleculeId;

					// MOLECULE_INFO.println("" + TAB + "  " + TAB + "- molecule-id:" + TAB + "" + moleculeId);
					// MOLECULE_INFO.println("" + TAB + "  " + TAB + "  molecule-smiles:" + TAB + "\""
					// + data.getEscapedSmiles(moleculeId) + "\"");
					// MOLECULE_INFO.println("" + TAB + "  " + TAB + "  molecule-activity:" + TAB + ""
					// + data.getFirstEndpointClassValue(moleculeId));

					removeOverlappingOccurences(map1);
					removeOverlappingOccurences(map2);

					mInfo.feature1occurences = (map1 == null ? 0 : map1.size());
					mInfo.feature2occurences = (map2 == null ? 0 : map2.size());

					// MOLECULE_INFO.println("" + TAB + "  " + TAB + "  feature-1-num-occurences:" + TAB + ""
					// + (map1 == null ? 0 : map1.size()));
					// MOLECULE_INFO.println("" + TAB + "  " + TAB + "  feature-2-num-occurences:" + TAB + ""
					// + (map2 == null ? 0 : map2.size()));

					// OCCURENCE_INFO.println("" + TAB + "  " + TAB + "  occurence-distances:");

					Double molDistance = null;
					int occCount = 0;
					int overlapCount = 0;
					// int noPathCount = 0;

					molDistance = 0.0;
					UndirectedGraph molGraph = MoleculeGraphs.getMoleculeGraph(molecule);

					for (List<RMap> occurence1 : map1)
					{
						for (List<RMap> occurence2 : map2)
						{
							if (occurence1.size() == 0 || occurence2.size() == 0)
							{
								System.err.println("empy distance map");
								System.exit(0);
								// proceed = false;
							}
							// if (!proceed)
							// break;

							double occDist = 0;
							double atompairCount = 0;
							boolean overlap = false;
							noPath = false;

							if (PrintStreams.isVerbose())
							{
								PrintStreams.VERBOSE.print(">> feat1 ");
								for (int i = 0; i < occurence1.size(); i++)
									PrintStreams.VERBOSE.print(" "
											+ molecule.getAtom(occurence1.get(i).getId1()).getAtomTypeName() + "("
											+ occurence1.get(i).getId1() + ")");
								PrintStreams.VERBOSE.println();

								PrintStreams.VERBOSE.print(">> feat2 ");
								for (int i = 0; i < occurence2.size(); i++)
									PrintStreams.VERBOSE.print(" "
											+ molecule.getAtom(occurence2.get(i).getId1()).getAtomTypeName() + "("
											+ occurence2.get(i).getId1() + ")");
								PrintStreams.VERBOSE.println();
							}

							for (int i = 0; i < occurence1.size(); i++)
							{
								int id1 = occurence1.get(i).getId1();
								IAtom atom1 = molecule.getAtom(id1);

								for (int j = 0; j < occurence2.size(); j++)
								{
									int id2 = occurence2.get(j).getId1();

									double atompairDist = 0;
									if (id1 == id2)
									{
										overlap = true;
										break;
									}
									else
									{
										// calculate distance form atom1 && atom2
										IAtom atom2 = molecule.getAtom(id2);
										List<Object> l = DijkstraShortestPath.findPathBetween(molGraph, atom1, atom2);
										if (l == null)
										{
											WARNING.println("no path found!! " + data.getFeature(feature1) + " "
													+ data.getFeature(feature2));
											noPath = true;
											break;
										}
										atompairDist = l.size();

										if (PrintStreams.isVerbose())
											PrintStreams.VERBOSE.println(">> dist between  " + atom1.getAtomTypeName() + "("
													+ id1 + ") and " + atom2.getAtomTypeName() + "(" + id2 + ") is "
													+ atompairDist);
									}

									occDist = (occDist * atompairCount + atompairDist) / (double) (atompairCount + 1);
									atompairCount++;
								}

								if (overlap || noPath)
									break;
							}

							if (noPath)
								noPathCount++;
							else
							// if (proceed)
							{
								if (overlap)
									occDist = 0;

								// update occurenceDist
								molDistance = (molDistance * occCount + occDist) / (double) (occCount + 1);
								occCount++;
								if (overlap)
									overlapCount++;
							}

							OccurenceInfo oInfo = new OccurenceInfo();
							oInfo.occCount = occCount;
							oInfo.noPath = noPath;
							oInfo.overlap = overlap;
							oInfo.occDist = occDist;
							// OCCURENCE_INFO.println("" + TAB + "  " + TAB + "  " + TAB + "- occurence-pair:" + TAB + ""
							// + occCount);
							// OCCURENCE_INFO.println("" + TAB + "  " + TAB + "  " + TAB + "  ommitted-occurence-no-path:"
							// + TAB + "" + noPath);
							// OCCURENCE_INFO.println("" + TAB + "  " + TAB + "  " + TAB + "  occurence-overlap:" + TAB + ""
							// + overlap);
							// OCCURENCE_INFO.printf("" + TAB + "  " + TAB + "  " + TAB + "  occurence-distance:" + TAB
							// + "%f\n", occDist);
							mInfo.occurences.add(oInfo);

							// if (!overlap)
							// System.exit(0);
						}
					}

					// if (!proceed)
					// molDistance = null;

					mInfo.noPathCount = noPathCount;
					mInfo.occCount = occCount;
					mInfo.overlapCount = overlapCount;
					mInfo.molDistance = molDistance;
					// MOLECULE_INFO.println("" + TAB + "  " + TAB + "  omitted-occurence-no-paths:" + TAB + "" + noPathCount);
					// MOLECULE_INFO.println("" + TAB + "  " + TAB + "  num-occurence-pairs:" + TAB + "" + occCount);
					// MOLECULE_INFO.println("" + TAB + "  " + TAB + "  num-overlaps:" + TAB + "" + overlapCount);
					// MOLECULE_INFO.println("" + TAB + "  " + TAB + "  molecule-distance:" + TAB + "" + molDistance);
					// MOLECULE_INFO.println();
					fpInfo.molecules.add(mInfo);

					// if (proceed)
					// {
					if (occCount > 0)
					{
						if (data.getFirstEndpointClassValue(moleculeId) == 1)
						{
							overallDistanceActive = (overallDistanceActive * molCountActive + molDistance)
									/ (double) (molCountActive + 1);
							molCountActive++;
							activeDistances.add(molDistance);
						}
						else
						{
							overallDistanceInactive = (overallDistanceInactive * molCountInactive + molDistance)
									/ (double) (molCountInactive + 1);
							molCountInactive++;
							inactiveDistances.add(molDistance);
						}

						avgNumPairs = (avgNumPairs * molCount + occCount) / (double) (molCount + 1);

						double overlapRatio = overlapCount / (double) occCount;
						overlapPerPairRatio = (overlapPerPairRatio * molCount + overlapRatio) / (double) (molCount + 1);

						// if (overlapPerPairRatio < 1)
						// System.exit(0);

						molCount++;
					}

				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}

			if (molCount > 0)
			{
				avgNoSubstructureOfMoleculeCount = (avgNoSubstructureOfMoleculeCount * numFeaturePairs + noSubstructureOfMoleculeCount)
						/ (double) (numFeaturePairs + 1);
				avgNumCommonMolecules = (avgNumCommonMolecules * numFeaturePairs + molCount)
						/ (double) (numFeaturePairs + 1);
				overallAvgOccurencePairs = (overallAvgOccurencePairs * numFeaturePairs + avgNumPairs)
						/ (double) (numFeaturePairs + 1);
				overallOverlapPerPairRatio = (overallOverlapPerPairRatio * numFeaturePairs + overlapPerPairRatio)
						/ (double) (numFeaturePairs + 1);
				// if (overallOverlapPerPairRatio < 1)
				// System.exit(0);
				overallNoPathPerFeaturePairRatio = (overallNoPathPerFeaturePairRatio * numFeaturePairs + noPathCount)
						/ (double) (numFeaturePairs + 1);
				overallAvgDistanceActive = (overallAvgDistanceActive * numFeaturePairs + overallDistanceActive)
						/ (double) (numFeaturePairs + 1);
				overallAvgDistanceInactive = (overallAvgDistanceInactive * numFeaturePairs + overallDistanceInactive)
						/ (double) (numFeaturePairs + 1);

				numFeaturePairs++;

				// if (molCount > 20 && activeDistances.size() > 0 && inactiveDistances.size() > 0)
				// {
				// resultBrowser.addResult(new DistanceResultBrowser.DistanceResult(data.getFeature(feature1) + " ("
				// + feature1 + ")", data.getFeature(feature2) + " (" + feature2 + ")", activeDistances,
				// inactiveDistances, data.getFirstEndpoint()));// , progressInfo());
				// }
			}
			else
			{
				// no entirely correct, but who cares

				if (noPath)
					skipFeaturesNoPath++;
				if (noSub)
					skipFeaturesNoSubstructure++;
			}
		}

		fpInfo.noSubstructureOfMoleculeCount = noSubstructureOfMoleculeCount;
		fpInfo.molCount = molCount;
		fpInfo.avgNumPairs = avgNumPairs;
		fpInfo.overlapPerPairRatio = overlapPerPairRatio;
		fpInfo.overallDistanceActive = overallDistanceActive;
		fpInfo.overallDistanceInactive = overallDistanceInactive;
		// FEATURE_INFO.println("" + TAB + "  num-no-substructure-of-molecule:" + TAB + "" + noSubstructureOfMoleculeCount);
		// FEATURE_INFO.println("" + TAB + "  num-common-molecules:" + TAB + "" + molCount);
		// FEATURE_INFO.println("" + TAB + "  avg-num-occurence-pairs:" + TAB + "" + avgNumPairs);
		// FEATURE_INFO.println("" + TAB + "  overlap-per-pair-ratio:" + TAB + "" + overlapPerPairRatio);
		// FEATURE_INFO.println("" + TAB + "  distance-active:" + TAB + "" + overallDistanceActive);
		// FEATURE_INFO.println("" + TAB + "  distance-inactive:" + TAB + "" + overallDistanceInactive);
		// FEATURE_INFO.println();
		fpInfo.print();

		return new double[] { overallDistanceActive, overallDistanceInactive };
	}

	private boolean onlyCCheck(IMolecule feat)
	{
		for (int i = 0; i < feat.getAtomCount(); i++)
		{
			String symbol = feat.getAtom(i).getSymbol();
			if (!symbol.equals("C") && !symbol.equals("c"))
				return true;
		}
		return false;
	}

	private int getBiggestOverlap(IMolecule f1, IMolecule f2)
	{
		if (f1.getAtomCount() == 1 || f2.getAtomCount() == 1)
		{
			for (int i = 0; i < f1.getAtomCount(); i++)
			{
				IAtom atom1 = f1.getAtom(i);
				for (int j = 0; j < f2.getAtomCount(); j++)
				{
					IAtom atom2 = f2.getAtom(j);

					if (atom1.getSymbol().equals(atom2.getSymbol()))
						return 1;
				}
			}
			return 0;
		}
		else
		{
			try
			{
				int overlap = 0;
				List<IAtomContainer> m = UniversalIsomorphismTester.getOverlaps(f1, f2);
				for (IAtomContainer a : m)
				{
					if (a.getAtomCount() > overlap)
						overlap = a.getAtomCount();
				}
				return overlap;
			}
			catch (CDKException e)
			{
				e.printStackTrace();
				System.exit(1);
				return -1;
			}
		}
	}

	private void removeOverlappingOccurences(List<List<RMap>> l)
	{
		List<Integer> atoms = new ArrayList<Integer>();
		boolean disjunct[] = new boolean[l.size()];

		int count = 0;
		for (List<RMap> occurence : l)
		{
			boolean match = false;
			for (int i = 0; i < occurence.size(); i++)
			{
				int a = occurence.get(i).getId1();
				for (int atom : atoms)
				{
					if (a == atom)
					{
						match = true;
						break;
					}
				}
				if (match)
					break;
			}
			if (match)
				disjunct[count] = false;
			else
			{
				disjunct[count] = true;
				for (int i = 0; i < occurence.size(); i++)
					atoms.add(occurence.get(i).getId1());
			}
			count++;
		}
		for (int i = disjunct.length - 1; i >= 0; i--)
			if (!disjunct[i])
				l.remove(i);

	}
}
