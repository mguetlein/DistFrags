package old.main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import old.util.FileNameUtils;
import old.util.PrintStreams;


public class LazarInputData extends InputData
{
	File classFile;
	File smilesFile;
	File featureFile;

	public static InputData getLazarInputData(String dataset, boolean open)
	{
		File f[] = FileNameUtils.getLazarInputFiles(dataset, open);
		return new LazarInputData(dataset, f[0], f[1], f[2], true);
	}

	private LazarInputData(String dataset, File classFile, File smilesFile, File featureFile, boolean featureOccAsLineNumber)
	{
		try
		{
			this.datasetName = dataset;
			this.classFile = classFile;
			this.smilesFile = smilesFile;
			this.featureFile = featureFile;

			readSmiles();
			readClassValues();
			readFeatures(featureOccAsLineNumber);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			System.exit(1);
		}
	}

	// public static String convert(String featureSmiles)
	// {
	// featureSmiles = featureSmiles.replace("c:n", "cn");
	// featureSmiles = featureSmiles.replace("n:c", "nc");
	// return featureSmiles;
	// }

	public void readFeatures(boolean featureOccAsLineNumber) throws Exception
	{
		PrintStreams.STATUS_INFO.println("Reading fragments: '" + featureFile.getName() + "'");
		if (featureOccAsLineNumber)
			PrintStreams.STATUS_INFO.println("Fragment occurences are stored as line numbers (instead of ids)");

		BufferedReader r = new BufferedReader(new FileReader(featureFile));
		String s;

		while ((s = r.readLine()) != null)
		{
			String fragment = null;
			String occurences = null;

			Pattern p = Pattern.compile("^(.*)\\[");
			Matcher m = p.matcher(s);
			if (m.find())
			{
				fragment = m.group(1).trim();
				// System.out.print(fragment + " ");
			}

			p = Pattern.compile("\\s\\[(.*)\\]$");
			m = p.matcher(s);
			if (m.find())
			{
				occurences = m.group(1);
				// System.out.println(occurences);
			}

			if (fragment == null || occurences == null)
				throw new IllegalStateException("wrong smiles file format, " + featureFile + ": '" + s + "', fragment:"
						+ fragment + ", occurences:" + occurences);

			if (features.contains(fragment))
				PrintStreams.WARNING.println("fragment occures twice " + fragment);

			// fragment = convert(fragment);
			features.add(fragment);

			Vector<Integer> ids = new Vector<Integer>();
			StringTokenizer tok = new StringTokenizer(occurences);

			while (tok.hasMoreTokens())
			{
				int occ = Integer.parseInt(tok.nextToken());

				int id = -1;
				if (featureOccAsLineNumber)
					id = moleculeIds.get(occ);
				else
					id = occ;

				if (id == -1)
					throw new IllegalStateException("illegal id, " + featureFile + ": '" + s + "', fragment:" + fragment
							+ ", occurences:" + occurences + ", ID: " + id);

				ids.add(id);
			}

			if (ids.size() == 0)
				throw new IllegalStateException("no occurences, " + featureFile + ": '" + s + "', fragment:" + fragment
						+ ", occurences:" + occurences);

			featureToMolecules.put(features.size() - 1, ids);
		}

		PrintStreams.STATUS_INFO.println("Read '" + features.size() + "' fragments");

		r.close();

		PrintStreams.STATUS_INFO.println("Building molecule to feature map");

		for (int featureIndex = 0; featureIndex < features.size(); featureIndex++)
		{
			Vector<Integer> ids = featureToMolecules.get(featureIndex);

			for (Integer id : ids)
			{
				Vector<Integer> features = moleculesToFeatures.get(id);
				if (features == null)
				{
					features = new Vector<Integer>();
					features.add(featureIndex);
					moleculesToFeatures.put(id, features);
				}
				else
					features.add(featureIndex);
			}
		}

		// for (Integer id : moleculeIds)
		// {
		// System.out.print(id + ": [ ");
		//
		// Vector<Integer> occ = moleculesToFeatures.get(id);
		// for (Integer i : occ)
		// System.out.print(i + " ");
		// System.out.println("]");
		// }

		PrintStreams.STATUS_INFO.println("'" + moleculesToFeatures.keySet().size() + "/" + moleculeIds.size()
				+ "' molecules have fragments");
	}

	public void readSmiles() throws Exception
	{
		PrintStreams.STATUS_INFO.println("Reading smiles: '" + smilesFile.getName() + "'");

		BufferedReader r = new BufferedReader(new FileReader(smilesFile));
		String s;

		// OBConversion c = new OBConversion();
		// OBMol mol = new OBMol();
		// c.SetInAndOutFormats("smi", "inchi");

		while ((s = r.readLine()) != null)
		{
			int id = -1;
			String smile = null;

			Pattern p = Pattern.compile("^([0-9]*)\\s");
			Matcher m = p.matcher(s);
			if (m.find())
			{
				id = Integer.parseInt(m.group(1));
				// System.out.print(id + " ");
			}

			p = Pattern.compile("\\s(.*)$");
			m = p.matcher(s);
			if (m.find())
			{
				smile = m.group(1);
				// System.out.println(smile);
			}

			if (id == -1 || smile == null)
				throw new IllegalStateException("wrong smiles file format, " + smilesFile + ": '" + s + "', id:" + id
						+ ", smiles:" + smile);

			if (moleculeIds.contains(id))
				throw new IllegalStateException("double id");
			moleculeIds.add(id);

			if (smiles.containsValue(smile))
				PrintStreams.VERBOSE.println("duplicate smiles " + smile);

			smiles.put(id, smile);

			// c.ReadString(mol, smile);
			// String inchi = c.WriteString(mol).trim();
			//
			// if (inchis.containsValue(inchi))
			// PrintStreams.warning("duplicate inchi " + inchi);
			//
			// System.out.println("smiles: '" + smile + "', inchi '" + inchi + "'");

			// inchis.put(id, inchi);
		}

		PrintStreams.STATUS_INFO.println("Read '" + moleculeIds.size() + "' smiles strings");

		r.close();
	}

	public void readClassValues() throws Exception
	{
		PrintStreams.STATUS_INFO.println("Reading class file: '" + classFile.getName() + "'");

		BufferedReader r = new BufferedReader(new FileReader(classFile));
		String s;

		while ((s = r.readLine()) != null)
		{
			// StringTokenizer tok = new StringTokenizer(s);

			int id = -1;
			String endpoint = null;
			Integer classValue = null;

			Pattern p = Pattern.compile("^([0-9]*)\\s");
			Matcher m = p.matcher(s);
			if (m.find())
			{
				id = Integer.parseInt(m.group(1));
				// System.out.print(id + " ");
			}

			p = Pattern.compile("\\s(\\\"(.*)\\\")\\s");
			m = p.matcher(s);
			if (m.find())
			{
				endpoint = m.group(1);
				// System.out.print(endpoint + " ");
			}
			else
			{
				p = Pattern.compile("\\t(.*)\\t");
				m = p.matcher(s);
				if (m.find())
				{
					endpoint = m.group(1);
					// System.out.println(endpoint + " ");
				}
			}

			p = Pattern.compile("\\s([0-1])$");
			m = p.matcher(s);
			if (m.find())
			{
				classValue = new Integer(m.group(1));
				// System.out.println(act);
			}

			if (id == -1 || endpoint == null || classValue == null)
				throw new IllegalStateException("wrong class file format, " + classFile + ": '" + s + "', id:" + id
						+ ", endpoint:" + endpoint + ", act:" + classValue);

			if (classValues.containsKey(getClassValueKey(id, endpoint)))
				throw new IllegalStateException("insert double val into db: " + getClassValueKey(id, endpoint));

			if (!endpoints.contains(endpoint))
				endpoints.add(endpoint);

			classValues.put(getClassValueKey(id, endpoint), classValue);
		}

		PrintStreams.STATUS_INFO.println("Read '" + classValues.keySet().size() + "' class values, '" + endpoints.size()
				+ "' different endpoints");

		r.close();
	}

	protected void printInputInfo()
	{
		PrintStreams.OUT.println("" + TAB + "class-file:" + TAB + "" + classFile);
		PrintStreams.OUT.println("" + TAB + "smiles-file:" + TAB + "" + smilesFile);
		PrintStreams.OUT.println("" + TAB + "feature-file:" + TAB + "" + featureFile);
	}
}
