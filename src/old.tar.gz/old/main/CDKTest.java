package old.main;
import java.util.List;

import org._3pq.jgrapht.UndirectedGraph;
import org._3pq.jgrapht.alg.DijkstraShortestPath;
import org.openscience.cdk.DefaultChemObjectBuilder;
import org.openscience.cdk.exception.CDKException;
import org.openscience.cdk.exception.InvalidSmilesException;
import org.openscience.cdk.graph.MoleculeGraphs;
import org.openscience.cdk.interfaces.IAtom;
import org.openscience.cdk.interfaces.IMolecule;
import org.openscience.cdk.isomorphism.UniversalIsomorphismTester;
import org.openscience.cdk.qsar.DescriptorValue;
import org.openscience.cdk.qsar.descriptors.molecular.BCUTDescriptor;
import org.openscience.cdk.qsar.result.IDescriptorResult;
import org.openscience.cdk.smiles.SmilesParser;

public class CDKTest
{
	public static void main(String args[])
	{
		BCUTDescriptor descriptor = new BCUTDescriptor();
		IMolecule molecule = null;
		IMolecule molecule2 = null;
		try
		{
			molecule = new SmilesParser(DefaultChemObjectBuilder.getInstance()).parseSmiles("NC(CS)C(=O)O");
			molecule2 = new SmilesParser(DefaultChemObjectBuilder.getInstance()).parseSmiles("CCC");
		}
		catch (InvalidSmilesException e)
		{
			e.printStackTrace();
		}
		DescriptorValue value = descriptor.calculate(molecule);
		IDescriptorResult theNumbers = value.getValue();

		IAtom i = molecule.getAtom(0);
		IAtom j = molecule.getAtom(3);

		molecule.getConnectedAtomsList(i);

		boolean b = false;

		try
		{
			b = UniversalIsomorphismTester.isSubgraph(molecule, molecule2);
		}
		catch (CDKException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		UndirectedGraph molGraph = MoleculeGraphs.getMoleculeGraph(molecule);
		List<Object> l = DijkstraShortestPath.findPathBetween(molGraph, i, j);
		int length = l.size();

		// for (Iterator it = molGraph.edgeSet().iterator(); it.hasNext();)
		// {
		// Edge edge = (Edge) it.next();
		// Object u = edge.getSource();
		// Object v = edge.getTarget();
		// }

		System.exit(0);

	}
}
