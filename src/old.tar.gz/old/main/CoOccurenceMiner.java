package old.main;
import java.awt.Point;
import java.util.HashMap;
import java.util.Vector;

/**
 * @author martin
 * 
 * 
 *         check how often a fragment occurs with other fragments
 * 
 */
public class CoOccurenceMiner
{
	/**
	 * Array of HashMaps, one for each fragment
	 * 
	 * HashMap: key: index of other fragment value: num-co-occurences
	 */
	private Vector<HashMap<Integer, Integer>> coOccurence = new Vector<HashMap<Integer, Integer>>();

	private Vector<Point> markedCoOccurences = new Vector<Point>();

	private InputData data;

	public CoOccurenceMiner(InputData data)
	{
		this.data = data;

		mineCoOccurences(0.5);
		// printCoOccurences();
	}

	public int getNumMarkedCoOcurrences()
	{
		return markedCoOccurences.size();
	}

	public int[] getMarkedCoOccurence(int index)
	{
		return new int[] { markedCoOccurences.get(index).x, markedCoOccurences.get(index).y };
	}

	private void printCoOccurences()
	{
		Vector<String> features = data.getFeatures();

		System.out.print("                                           ");
		for (int i = 0; i < features.size(); i++)
			System.out.printf("  %4d", (i + 1));
		System.out.println("\n");

		for (int i = 0; i < features.size(); i++)
		{
			int total_i = data.getMoleculesForFeature(i).size();
			HashMap<Integer, Integer> occ_i = coOccurence.get(i);

			System.out.printf("%3d: %28s %4d     ", (i + 1), features.get(i), total_i);

			for (int j = 0; j < features.size(); j++)
			{
				if (i < j)
					continue;
				else if (i == j)
					System.out.printf("  %4s", "x");
				else if (features.get(i).contains(features.get(j)) || features.get(j).contains(features.get(i)))
					System.out.printf("  %4s", "-");
				else
				{
					if (occ_i.containsKey(j))
					{
						int total_j = data.getMoleculesForFeature(j).size();
						HashMap<Integer, Integer> occ_j = coOccurence.get(j);
						double product = (occ_i.get(j) / (double) total_i) * (occ_j.get(i) / (double) total_j);

						System.out.printf("  %4.2f", product);

						// double o = (occ.get(j) / (double) total);
						// if (o < 0.5)
						// System.out.printf("  %4s", "-");
						// else
						// System.out.printf("  %4d", occ_i.get(j));
						// System.out.printf("  %4.2f", o);
					}
					else
						System.out.printf("  %4s", "-");
				}
			}

			System.out.println();
		}

		System.out.println();
		System.out.print("                                           ");
		for (int i = 0; i < features.size(); i++)
			System.out.printf("  %4d", (i + 1));
		System.out.println("\n");

		for (int i = 0; i < features.size(); i++)
		{
			int total = data.getMoleculesForFeature(i).size();

			System.out.printf("%3d: %28s %4d     ", (i + 1), features.get(i), total);

			for (int j = 0; j < features.size(); j++)
			{
				if (i < j)
					continue;
				else if (i == j)
					System.out.printf("  %4s", "x");
				else if (markedCoOccurences.contains(new Point(i, j)))
					System.out.printf("  %4s", "O");
				else
					System.out.printf("  %4s", "-");
			}

			System.out.println();
		}
	}

	private void mineCoOccurences(double productOccurenceThreshold)
	{
		Vector<String> features = data.getFeatures();

		for (int i = 0; i < features.size(); i++)
			coOccurence.add(new HashMap<Integer, Integer>());

		Vector<Integer> moleculeIds = data.getMoleculeIds();

		for (Integer id : moleculeIds)
		{
			Vector<Integer> f = data.getFeaturesForMolecule(id);
			if (f == null)
				continue;

			for (int i = 0; i < f.size() - 1; i++)
			{
				for (int j = i + 1; j < f.size(); j++)
				{
					int featureI = f.get(i);
					int featureJ = f.get(j);

					HashMap<Integer, Integer> m = coOccurence.get(featureI);
					if (m.containsKey(featureJ))
						m.put(featureJ, m.get(featureJ) + 1);
					else
						m.put(featureJ, 1);

					m = coOccurence.get(featureJ);
					if (m.containsKey(featureI))
						m.put(featureI, m.get(featureI) + 1);
					else
						m.put(featureI, 1);
				}
			}
		}

		for (int i = 0; i < features.size(); i++)
		{
			int total_i = data.getMoleculesForFeature(i).size();
			HashMap<Integer, Integer> occ_i = coOccurence.get(i);

			for (int j = 0; j < features.size(); j++)
			{
				if (i <= j)
					continue;
				else if (features.get(i).contains(features.get(j)) || features.get(j).contains(features.get(i)))
					continue;
				else if (occ_i.containsKey(j))
				{
					int total_j = data.getMoleculesForFeature(j).size();
					HashMap<Integer, Integer> occ_j = coOccurence.get(j);
					double product = (occ_i.get(j) / (double) total_i) * (occ_j.get(i) / (double) total_j);

					if (product >= productOccurenceThreshold)
					{
						markedCoOccurences.add(new Point(i, j));
					}
				}
			}
		}
	}
}
