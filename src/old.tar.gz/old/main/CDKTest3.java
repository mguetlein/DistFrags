package old.main;

import java.util.List;

import org.openscience.cdk.DefaultChemObjectBuilder;
import org.openscience.cdk.exception.CDKException;
import org.openscience.cdk.interfaces.IAtom;
import org.openscience.cdk.interfaces.IAtomContainer;
import org.openscience.cdk.interfaces.IMolecule;
import org.openscience.cdk.isomorphism.UniversalIsomorphismTester;
import org.openscience.cdk.smiles.SmilesParser;

public class CDKTest3
{
	@SuppressWarnings("unchecked")
	public static void main(String args[])
	{
		try
		{
			// IMolecule m1 = new SmilesParser(DefaultChemObjectBuilder.getInstance()).parseSmiles("CCCNC");
			// IMolecule m2 = new SmilesParser(DefaultChemObjectBuilder.getInstance()).parseSmiles("O");

			IMolecule m1 = new SmilesParser(DefaultChemObjectBuilder.getInstance()).parseSmiles("C=0");
			IMolecule m2 = new SmilesParser(DefaultChemObjectBuilder.getInstance()).parseSmiles("C-C-O");

			int overlap = getBiggestOverlap(m1, m2);
			System.out.println("Overlap with size " + overlap);

		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

	}

	private static int getBiggestOverlap(IMolecule f1, IMolecule f2)
	{
		if (f1.getAtomCount() == 1 || f2.getAtomCount() == 1)
		{
			for (int i = 0; i < f1.getAtomCount(); i++)
			{
				IAtom atom1 = f1.getAtom(i);
				for (int j = 0; j < f2.getAtomCount(); j++)
				{
					IAtom atom2 = f2.getAtom(j);

					if (atom1.getSymbol().equals(atom2.getSymbol()))
						return 1;
				}
			}
			return 0;
		}
		else
		{
			try
			{
				int overlap = 0;
				List<IAtomContainer> m = UniversalIsomorphismTester.getOverlaps(f1, f2);
				for (IAtomContainer a : m)
				{
					if (a.getAtomCount() > overlap)
						overlap = a.getAtomCount();
				}
				return overlap;
			}
			catch (CDKException e)
			{
				e.printStackTrace();
				System.exit(1);
				return -1;
			}
		}
	}
}
