package old.main;

public class DistFragsLauncher
{
	public static void distanceMineCPDBData()
	{
		String cpdb[] = new String[] { "hamster_carcinogenicity", "hamster_female_carcinogenicity",
				"hamster_male_carcinogenicity", "mouse_carcinogenicity", "mouse_female_carcinogenicity",
				"mouse_male_carcinogenicity", "multi_cell_call", "rat_carcinogenicity", "rat_female_carcinogenicity",
				"rat_male_carcinogenicity", "salmonella_mutagenicity", "single_cell_call" };

		// int count = 0;

		for (String dataset : cpdb)
		{
			new FeatureDistanceCalculator(dataset);

			// if (count >= 1)
			// break;
			// count++;

		}
	}

	public static void main(String args[])
	{
		DistFragsLauncher.distanceMineCPDBData();
	}
}
