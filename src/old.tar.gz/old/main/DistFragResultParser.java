package old.main;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import old.util.FileNameUtils;
import old.util.PrintStreams;

import org.jvyaml.YAML;


public class DistFragResultParser implements DistFragsConstants
{
	Vector<DistFragsResult> results = new Vector<DistFragsResult>();

	// DistanceResultBrowser browser = new DistanceResultBrowser();

	public static void main(String args[])
	{
		// new DistFragResultParser("/home/martin/tmp/dist.out.2");
		// new DistFragResultParser("/home/martin/tmp/dist.out.salmonella.selected.orig.3");

		// String cpdb[] = new String[] { "hamster_carcinogenicity", "hamster_female_carcinogenicity",
		// "hamster_male_carcinogenicity", "mouse_carcinogenicity", "mouse_female_carcinogenicity",
		// "mouse_male_carcinogenicity", "multi_cell_call", "rat_carcinogenicity", "rat_female_carcinogenicity",
		// "rat_male_carcinogenicity", "salmonella_mutagenicity", "single_cell_call" };

		String datset = "hamster_carcinogenicity";
		// DistFrags.DATASET = "hamster_female_carcinogenicity";
		// DistFrags.DATASET = "hamster_male_carcinogenicity";
		// DistFrags.DATASET = "mouse_carcinogenicity";
		// DistFrags.DATASET = "mouse_female_carcinogenicity";
		// DistFrags.DATASET = "mouse_male_carcinogenicity";
		// DistFrags.DATASET = "multi_cell_call";
		// DistFrags.DATASET = "rat_carcinogenicity";

		new DistFragResultParser(datset);// DATASET, FEATURES));

	}

	public Vector<DistFragsResult> getResults()
	{
		return results;
	}

	@SuppressWarnings("unchecked")
	public DistFragResultParser(String dataset)
	{
		String file = FileNameUtils.getDistFragsOutfile(dataset);

		try
		{
			PrintStreams.STATUS_INFO.print("reading yaml file: " + file + " ... ");
			Map configuration = (Map) YAML.load(new FileReader(file));
			PrintStreams.STATUS_INFO.println("done");

			String endpoint = "";

			Map inputData = (Map) configuration.get("input-data");
			List<Map> endpoints = (List) inputData.get("endpoints");
			for (Map e : endpoints)
				endpoint = (String) e.get("name");

			List<Map> distancePairs = (List) configuration.get("distance-pairs");

			if (distancePairs.size() == 0)
			{
				System.err.println("no distdance pairs found");
				System.exit(0);
			}

			int count = 0;

			for (Map pair : distancePairs)
			{
				List<Map> commonMolecules = (List) pair.get("common-molecules");

				if (commonMolecules != null && commonMolecules.size() >= MIN_NUM_COMMON_MOLECULES)
				{

					Vector<Double> activeDistances = new Vector<Double>();
					Vector<Double> inactiveDistances = new Vector<Double>();
					HashMap<Integer, Double> moleculeDistance = new HashMap<Integer, Double>();

					for (Map mol : commonMolecules)
					{
						Double d = (Double) mol.get("molecule-distance");
						assert (d != null);

						if (((Long) mol.get("molecule-activity")) == 1)
							activeDistances.add(d);
						else
							inactiveDistances.add(d);

						Integer i = ((Long) mol.get("molecule-id")).intValue();
						moleculeDistance.put(i, d);

						// Object val = configuration.get(key);
					}

					if (activeDistances.size() >= MIN_NUM_COMMON_MOLECULES_FOR_EACH_CLASS
							&& inactiveDistances.size() >= MIN_NUM_COMMON_MOLECULES_FOR_EACH_CLASS)
					{
						DistFragsResult res = new DistFragsResult(pair.get("feature-1-smiles").toString(), pair.get(
								"feature-2-smiles").toString(), moleculeDistance, activeDistances, inactiveDistances,
								endpoint);
						if (res.isSignificant())
							results.add(res);
					}
				}
				count++;
				// if (count % 1000 == 0)
				// System.out.println(count + "/" + distancePairs.size());
			}
			PrintStreams.STATUS_INFO.println("Total number of pairs: " + distancePairs.size());
			PrintStreams.STATUS_INFO.println("Added to results: " + results.size());

			// browser.showStats();

		}
		catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
