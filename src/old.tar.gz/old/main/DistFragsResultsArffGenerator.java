package old.main;

import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Vector;

import old.util.FileNameUtils;


public class DistFragsResultsArffGenerator
{
	InputData data;
	Vector<DistFragsResult> results;

	static PrintStream ARFF = System.out;

	public static void main(String args[])
	{
		// String dataset = "hamster_carcinogenicity";
		String dataset = "salmonella_mutagenicity";
		// DistFrags.DATASET = "hamster_female_carcinogenicity";
		// DistFrags.DATASET = "hamster_male_carcinogenicity";
		// String dataset = "mouse_carcinogenicity";
		// DistFrags.DATASET = "mouse_female_carcinogenicity";
		// DistFrags.DATASET = "mouse_male_carcinogenicity";
		// DistFrags.DATASET = "multi_cell_call";
		// DistFrags.DATASET = "rat_carcinogenicity";

		try
		{
			ARFF = new PrintStream(FileNameUtils.getDistFragsArffFile(dataset, false));
		}
		catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		new DistFragsResultsArffGenerator(dataset);
	}

	static abstract class ThresholdCondition
	{
		public abstract boolean isThresholdReached();

		public static ThresholdCondition getThresholdCondition_NoThreshold()
		{
			return new ThresholdCondition()
			{
				@Override
				public boolean isThresholdReached()
				{
					return false;
				}
			};
		}
	}

	public DistFragsResultsArffGenerator(String dataset)
	{
		data = LazarInputData.getLazarInputData(dataset, false);
		results = new DistFragResultParser(dataset).getResults();

		Collections.sort(results, new Comparator<DistFragsResult>()
		{
			@Override
			public int compare(DistFragsResult o1, DistFragsResult o2)
			{
				double delta = o1.stats - o2.stats;
				if (delta > 0)
					return 1;
				else if (delta < 0)
					return -1;
				else
					return 0;
			}
		});

		ARFF.println("% generated: " + new SimpleDateFormat("yyyy.MM.dd HH:mm:ss").format(new Date()));
		ARFF.println("% num features (fragment pairs): " + results.size());
		ARFF.println();
		ARFF.println("@relation \"" + data.getDatasetName() + " distance-fragments\"");
		ARFF.println();

		ThresholdCondition threshold = ThresholdCondition.getThresholdCondition_NoThreshold();

		for (DistFragsResult res : results)
		{
			if (threshold.isThresholdReached())
				break;

			ARFF.println("@attribute " + res.feature1 + "_distance_to_" + res.feature2 + " numeric");
		}
		ARFF.println("@attribute " + data.getFirstEndpoint() + " {0,1}");
		ARFF.println();

		ARFF.println("@data");

		for (Integer moleculeId : data.moleculeIds)
		{

			boolean first = true;

			for (int i = 0; i < results.size(); i++)
			{
				if (threshold.isThresholdReached())
					break;

				Double d = results.get(i).getDistance(moleculeId);

				if (d != null)
				{
					if (!first)
						ARFF.print(", ");
					else
					{
						ARFF.print("{");
						first = false;
					}
					ARFF.print(i + " " + d);
				}
			}
			if (!first)
				ARFF.println("}");
		}

	}
}
