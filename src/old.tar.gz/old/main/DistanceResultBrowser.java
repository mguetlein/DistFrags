package old.main;

import java.awt.Frame;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import freechart.HistogramDemo;

public class DistanceResultBrowser implements Runnable
{
	Vector<Double> stats = new Vector<Double>();

	// FeatureDistanceCalculator featDistCalc;

	Vector<DistFragsResult> results = new Vector<DistFragsResult>();

	Thread th;

	HistogramDemo demo;

	int index = 0;

	String additionalInfo;

	Object syncObject = new Object();

	public static void main(String args[])
	{
		// String dataset = "hamster_carcinogenicity";
		// DistFrags.DATASET = "hamster_female_carcinogenicity";
		// DistFrags.DATASET = "hamster_male_carcinogenicity";
		// String dataset = "mouse_carcinogenicity";
		// DistFrags.DATASET = "mouse_female_carcinogenicity";
		// DistFrags.DATASET = "mouse_male_carcinogenicity";
		// DistFrags.DATASET = "multi_cell_call";
		// DistFrags.DATASET = "rat_carcinogenicity";
		String dataset = "salmonella_mutagenicity";

		new DistanceResultBrowser(dataset);
	}

	public DistanceResultBrowser(String dataset)
	{
		DistFragResultParser parser = new DistFragResultParser(dataset);

		for (DistFragsResult distFragsResult : parser.getResults())
		{
			addResult(distFragsResult);
		}
		showStats();
	}

	public void showStats()
	{
		double[] v = new double[stats.size()];
		for (int i = 0; i < v.length; i++)
			v[i] = stats.get(i);

		Vector<double[]> wrap = new Vector<double[]>();
		wrap.add(v);

		Vector<String> subtitiles = new Vector<String>();
		subtitiles.add(stats.size() + " num pairs total");

		HistogramDemo demo = new HistogramDemo((Frame) null, "Stats", subtitiles, "Stats", "Stats", "Num pairs",
				(Vector<String>) null, wrap, 40);
		demo.setVisible(true);
	}

	public synchronized void addResult(DistFragsResult res)
	{
		stats.add(res.stats);

		// if (!res.isSignificant())
		// return;

		synchronized (syncObject)
		{
			results.add(res);
			if (demo != null)
			{
				List<String> s = new ArrayList<String>();
				s.add("Result: " + (index + 1) + "/" + results.size());
				s.add(results.get(index).statsString);
				// if (featDistCalc != null)
				// s.add(featDistCalc.getProgressInfo());
				demo.updateSubtitle(s);
			}
		}

		if (th == null)
			start();
	}

	private void start()
	{
		th = new Thread(this);
		th.start();
	}

	public void run()
	{
		while (true)
		{

			if (results.size() > index)
			{
				synchronized (syncObject)
				{
					DistFragsResult r = results.get(index);

					Vector<double[]> v = new Vector<double[]>();
					v.add(r.activeDistances);
					v.add(r.inactiveDistances);

					Vector<String> s = new Vector<String>();
					s.add("Active molecules");
					s.add("Inactive molecules");

					List<String> sub = new ArrayList<String>();
					sub.add("Result: " + (index + 1) + "/" + results.size());
					sub.add(r.statsString);

					// if (featDistCalc != null)
					// sub.add(featDistCalc.getProgressInfo());

					demo = new HistogramDemo(null, "Distance between " + r.feature1 + " and " + r.feature2, sub, r.endpoint,
							"Distance in bonds", "Apperances in molecules", s, v, 10);
				}
				demo.setVisible(true);

				if (demo.exitAndBack && index > 0)
					index--;
				else if (index < results.size() - 1)
					index++;
			}
			// try
			// {
			// Thread.sleep(100);
			// }
			// catch (InterruptedException e)
			// {
			// e.printStackTrace();
			// }
		}
	}
}
