package old.main;

import java.util.List;

import org.openscience.cdk.CDKConstants;
import org.openscience.cdk.DefaultChemObjectBuilder;
import org.openscience.cdk.interfaces.IAtom;
import org.openscience.cdk.interfaces.IBond;
import org.openscience.cdk.interfaces.IMolecule;
import org.openscience.cdk.isomorphism.UniversalIsomorphismTester;
import org.openscience.cdk.isomorphism.mcss.RMap;
import org.openscience.cdk.smiles.SmilesParser;

public class CDKTest2
{
	@SuppressWarnings("unchecked")
	public static void main(String args[])
	{
		try
		{
			String s[] = { "Cl-C-C", "C=C-O-C=C", "C=C-O-C=C", "N-C=N", "N-C=N", "C=C-O-C=C", "C-C-C-O-C-C" };
			String m[] = { "c1ccc(Cl)c1", "C=COC=C", "C1=CC=CO1", "C1=NC=CN1", "C1=NC2=C(C=CC(=C2))N1",
					"c2cccc(Oc1ccccc1)c2", "O=C1C2=C(C=CC=C2)C(=O)O1" };

			int start = 0;
			int end = 7;// s.length;

			for (int i = start; i < end; i++)
			{
				System.out.println("search " + s[i]);
				System.out.println("mol    " + m[i]);

				IMolecule molecule = new SmilesParser(DefaultChemObjectBuilder.getInstance()).parseSmiles(m[i]);
				IMolecule search = new SmilesParser(DefaultChemObjectBuilder.getInstance()).parseSmiles(s[i]);

				System.out.println("molecule ");
				System.out.print("       | ");
				for (int j = 0; j < molecule.getAtomCount(); j++)
				{
					IAtom a = molecule.getAtom(j);
					System.out.printf("%2s(%2d) | ", a.getSymbol(), j);
				}
				System.out.println();

				for (int j = 0; j < molecule.getAtomCount(); j++)
				{
					IAtom a = molecule.getAtom(j);
					System.out.printf("%2s(%2d) | ", a.getSymbol(), j);

					for (int k = 0; k < molecule.getAtomCount(); k++)
					{
						if (j == k)
							System.out.print("       | ");
						else
						{
							IBond bond = molecule.getBond(a, molecule.getAtom(k));
							if (bond == null)
								System.out.print("       | ");
							else
							{
								IBond.Order order = bond.getOrder();
								int n = 0;
								if (order == CDKConstants.BONDORDER_SINGLE)
									n = 1;
								else if (order == CDKConstants.BONDORDER_DOUBLE)
									n = 2;
								else if (order == CDKConstants.BONDORDER_TRIPLE)
									n = 3;
								String aromatic = " ";
								if (bond.getFlag(CDKConstants.ISAROMATIC))
									aromatic = "a";

								System.out.printf("%d%s     | ", n, aromatic);
							}
						}
					}
					System.out.println();
				}
				System.out.println();

				int count = 0;
				if (UniversalIsomorphismTester.isSubgraph(molecule, search))
				{
					List<List<RMap>> rmap = UniversalIsomorphismTester.getSubgraphAtomsMaps(molecule, search);
					for (List<RMap> map : rmap)
					{
						System.out.print("Atoms of search in molecule: ' ");
						for (int j = 0; j < map.size(); j++)
						{
							RMap rm = map.get(j);
							System.out.print(search.getAtom(rm.getId2()).getSymbol() + "(" + rm.getId2() + ") -> "
									+ molecule.getAtom(rm.getId1()).getSymbol() + "(" + rm.getId1() + ")   ");
						}
						System.out.println("'");
						count++;
					}
				}

				if (count == 0)
					System.out.println("no substructure");
				else
					System.out.println("occurences: " + count);

				if (count > 0)
					System.out.println("OK\n");
				else
				{
					System.out.flush();
					System.err.println("ERROR\n");
					System.err.flush();
					// System.exit(1);
				}
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

	}
}
