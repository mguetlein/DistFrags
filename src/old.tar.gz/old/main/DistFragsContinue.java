package old.main;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;

public class DistFragsContinue
{
	private boolean alreadyFinished;

	private boolean continueOK;

	private int feature1;

	private int feature2;

	public DistFragsContinue(File alreadyExistingOutfile)
	{
		try
		{
			String command = "/home/martin/software/bash/dist01_continue.sh " + alreadyExistingOutfile.getAbsolutePath();

			Process child = Runtime.getRuntime().exec(command);

			BufferedReader buffy = new BufferedReader(new InputStreamReader(child.getInputStream()));
			String s = "";
			String output = null;
			while ((s = buffy.readLine()) != null)
			{
				// System.out.println(s);
				if (output == null)
					output = s;
			}
			buffy.close();

			int value = child.waitFor();

			if (value == 0)
			{
				if (output.equals("finished"))
					alreadyFinished = true;
				else
				{
					int index = output.indexOf(' ');
					if (index != -1)
					{
						feature1 = Integer.parseInt(output.substring(0, index));
						feature2 = Integer.parseInt(output.substring(index + 1));
						if (feature1 != -1 && feature2 != -1)
							continueOK = true;
					}
				}
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public boolean isContinueOK()
	{
		return continueOK;
	}

	public int getFeature1()
	{
		return feature1;
	}

	public int getFeature2()
	{
		return feature2;
	}

	public boolean isAlreadyFinished()
	{
		return alreadyFinished;
	}

	public static void main(String args[])
	{
		DistFragsContinue cont = new DistFragsContinue(new File("/home/martin/results/distance/hamster.test.dist"));
		System.out.println(cont.isContinueOK());
		System.out.println(cont.getFeature1());
		System.out.println(cont.getFeature2());

	}

}
