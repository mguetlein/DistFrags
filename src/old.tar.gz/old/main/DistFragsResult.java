package old.main;

import java.util.ArrayList;
import java.util.Formatter;
import java.util.HashMap;
import java.util.List;
import java.util.Vector;

import org.apache.commons.math.stat.inference.TestUtils;

public class DistFragsResult
{
	String feature1;
	String feature2;

	double[] activeDistances;
	double[] inactiveDistances;

	HashMap<Integer, Double> moleculeDistance;

	String endpoint;

	double stats;
	String statsString;

	public DistFragsResult(String feature1, String feature2, HashMap<Integer, Double> moleculeDistance,
			Vector<Double> active, Vector<Double> inactive, String endpoint)
	{
		this.feature1 = feature1;
		this.feature2 = feature2;

		this.moleculeDistance = moleculeDistance;

		activeDistances = new double[active.size()];
		for (int i = 0; i < activeDistances.length; i++)
			activeDistances[i] = active.get(i);

		inactiveDistances = new double[inactive.size()];
		for (int i = 0; i < inactiveDistances.length; i++)
			inactiveDistances[i] = inactive.get(i);

		this.endpoint = endpoint;

		doStatisticalTest(activeDistances, inactiveDistances);
	}

	public Double getDistance(int moleculeId)
	{
		return moleculeDistance.get(moleculeId);
	}

	public boolean isSignificant()
	{
		// return true;
		return stats != 0 && stats < 0.05;
	}

	private void doStatisticalTest(double[] activeDistance, double inActiveDistance[])
	{
		// double distances[] = Arrays.copyOf(activeDistance, activeDistance.length + inActiveDistance.length);
		// for (int i = activeDistance.length; i < activeDistance.length + inActiveDistance.length; i++)
		// distances[i] = inActiveDistance[i - activeDistance.length];
		//
		// long activity[] = new long[distances.length];
		// Arrays.fill(activity, 0, activeDistance.length, 1);
		//
		// ChiSquareTestImpl chi = new ChiSquareTestImpl();
		// double d = chi.chiSquareTest(distances, activity);

		try
		{
			List<double[]> classes = new ArrayList<double[]>();
			classes.add(activeDistance);
			classes.add(inActiveDistance);

			double pValue = TestUtils.oneWayAnovaPValue(classes);
			stats = pValue;

			StringBuffer b = new StringBuffer();
			Formatter f = new Formatter(b);
			f.format("Test %.4f", pValue);
			statsString = b.toString();
		}
		catch (Exception e)
		{
			stats = 0;
			statsString = e.getMessage();
			// e.printStackTrace();
			// return e.getMessage();
		}

	}

}
