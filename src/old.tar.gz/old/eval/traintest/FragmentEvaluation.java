package old.eval.traintest;


public class FragmentEvaluation // extends TrainTestEvaluation
{
	// public FragmentEvaluation(MoleculeActivityData trainData, MoleculeActivityData testData)
	// {
	// super(trainData, testData);
	// }
	//
	// private FragmentMoleculeData trainFragments;
	// private FragmentMoleculeData testFragments;
	//
	// protected FragmentMoleculeData getTrainingFragments()
	// {
	// if (trainFragments == null)
	// trainFragments = FragmentFactory.mineFragments(getTrainingData());
	// return trainFragments;
	// }
	//
	// protected FragmentMoleculeData getTestFragments()
	// {
	// if (testFragments == null)
	// testFragments = FragmentFactory.checkFragments(getTestData(), trainFragments);
	// return testFragments;
	// }
	//
	// @Override
	// public File getTestArffFile()
	// {
	// File file = DataFileManager.getArffFile(getTestData().getDatasetName(), FragmentFactory.LINFRAG_FRAGMENT_NAME);
	// if (!file.exists())
	// ArffWriterFactory.writeFragmentDataToArff(file, getTestData(), getTestFragments());
	// return file;
	// }
	//
	// @Override
	// public File getTrainArffFile()
	// {
	// File file = DataFileManager.getArffFile(getTrainingData().getDatasetName(), FragmentFactory.LINFRAG_FRAGMENT_NAME);
	// if (!file.exists())
	// ArffWriterFactory.writeFragmentDataToArff(file, getTrainingData(), getTrainingFragments());
	// return file;
	// }
	//
}
