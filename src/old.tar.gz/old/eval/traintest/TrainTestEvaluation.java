package old.eval.traintest;

import java.io.File;
import java.util.List;

import weka.classifiers.Evaluation;
import data.MoleculeActivityData;
import eval.WekaEval;

public abstract class TrainTestEvaluation
{
	public abstract File getTrainArffFile();

	public abstract File getTestArffFile();

	private List<Evaluation> results;

	private MoleculeActivityData trainData;
	private MoleculeActivityData testData;

	protected TrainTestEvaluation(MoleculeActivityData trainData, MoleculeActivityData testData)
	{
		this.trainData = trainData;
		this.testData = testData;
	}

	protected MoleculeActivityData getTestData()
	{
		// if (testData == null)
		// testData = MoleculeFactory.getMoleculeActivityData(testDatasetName);
		return testData;
	}

	protected MoleculeActivityData getTrainingData()
	{
		// if (trainData == null)
		// trainData = MoleculeFactory.getMoleculeActivityData(trainDatasetName);
		return trainData;
	}

	// public void printResults()
	// {
	// for (int i = 0; i < results.size(); i++)
	// {
	// Status.INFO.println("Classifier: " + WekaEval.CLASSIFIERS.get(i).getClass().getSimpleName());
	// Status.INFO.println(Status.TAB + "Accuracy: " + StringUtil.formatDouble(results.get(i).pctCorrect()));
	// Status.INFO.println(Status.TAB + "Instances (correct/incorrect): " + (int) results.get(i).numInstances() + " ("
	// + (int) results.get(i).correct() + "/" + (int) results.get(i).incorrect());
	// }
	// }

	public void evaluate()
	{
		// results =
		WekaEval.evalTrainTest(getTrainArffFile(), getTestArffFile());
		// printResults();
	}

	// public List<Evaluation> evaluationResult()
	// {
	// results = WekaEval.evalTrainTest(getTrainArffFile(), getTestArffFile());
	// return results;
	// }

}
