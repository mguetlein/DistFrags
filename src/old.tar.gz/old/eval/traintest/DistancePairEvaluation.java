package old.eval.traintest;


public class DistancePairEvaluation // extends FragmentEvaluation
{
	// public DistancePairEvaluation(MoleculeActivityData trainData, MoleculeActivityData testData)
	// {
	// super(trainData, testData);
	// }
	//
	// private DistancePairData trainPairs;
	// private DistancePairData testPairs;
	//
	// protected DistancePairData getTrainingDistancePairs()
	// {
	// if (trainPairs == null)
	// trainPairs = DistancePairFactory.mineDistancePairs(getTrainingData(), getTrainingFragments());
	// return trainPairs;
	// }
	//
	// protected DistancePairData getTestDistancePairs()
	// {
	// if (testPairs == null)
	// testPairs = DistancePairFactory
	// .checkDistancePairs(getTestData(), getTestFragments(), getTrainingDistancePairs());
	// return testPairs;
	// }
	//
	// @Override
	// public File getTestArffFile()
	// {
	// File file = DataFileManager.getArffFile(getTestData().getDatasetName(),
	// DistancePairFactory.DISTANCE_PAIR_FRAGMENT_NAME);
	// if (!file.exists())
	// ArffWriterFactory.writeDistancePairDataToArff(file, getTestData(), getTestDistancePairs());
	// return file;
	// }
	//
	// @Override
	// public File getTrainArffFile()
	// {
	// File file = DataFileManager.getArffFile(getTrainingData().getDatasetName(),
	// DistancePairFactory.DISTANCE_PAIR_FRAGMENT_NAME);
	// if (!file.exists())
	// ArffWriterFactory.writeDistancePairDataToArff(file, getTrainingData(), getTrainingDistancePairs());
	// return file;
	// }

}
