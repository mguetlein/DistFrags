package old.eval.traintest;


public class FragmentAndDistancePairEvaluation // extends TrainTestEvaluation
{
	// MoleculeActivityData trainData;
	// FragmentMoleculeData trainFragments;
	// DistancePairData trainPairs;
	// MoleculeActivityData testData;
	//
	// FragmentMoleculeData testFragments;
	// DistancePairData testPairs;
	//
	// public FragmentAndDistancePairEvaluation(MoleculeActivityData trainData, FragmentMoleculeData trainFragments,
	// DistancePairData trainPairs, MoleculeActivityData testData)
	// {
	// this.trainData = trainData;
	// this.trainFragments = trainFragments;
	// this.trainPairs = trainPairs;
	// this.testData = testData;
	// }
	//
	// public void setTestFragments(FragmentMoleculeData testFragments)
	// {
	// this.testFragments = testFragments;
	// }
	//
	// public void setTestDistancePairs(DistancePairData testPairs)
	// {
	// this.testPairs = testPairs;
	// }
	//
	// @Override
	// public File getTestArffFile()
	// {
	// File file = DataFileManager.getCombinedArffFile(testData.getDatasetName(), trainFragments.getFragmentName(),
	// trainPairs.getFragmentName());
	// if (!file.exists())
	// {
	// if (testFragments == null)
	// {
	// testFragments = FragmentFactory.checkFragments(testData, trainFragments);
	// }
	// if (testPairs == null)
	// {
	// testPairs = DistancePairFactory.checkDistancePairs(testData, testFragments, trainPairs);
	// }
	//
	// // DebugUtil.printMoleculesWithDistPairs(testData, testPairs);
	//
	// ArffWriterFactory.writeFragmentAndDistancePairDataToArff(file, testData, trainFragments, testPairs);
	// }
	// return file;
	// }
	//
	// @Override
	// public File getTrainArffFile()
	// {
	// File file = DataFileManager.getCombinedArffFile(trainData.getDatasetName(), trainFragments.getFragmentName(),
	// trainPairs.getFragmentName());
	// if (!file.exists())
	// {
	// ArffWriterFactory.writeFragmentAndDistancePairDataToArff(file, trainData, trainFragments, trainPairs);
	// }
	// return file;
	// }

}
