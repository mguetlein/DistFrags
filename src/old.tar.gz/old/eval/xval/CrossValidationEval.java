package old.eval.xval;

import io.Status;

import java.util.List;

import old.eval.traintest.TrainTestEvaluation;
import util.StringUtil;
import weka.classifiers.Evaluation;
import data.MoleculeActivityData;
import data.util.CrossValidation;
import eval.WekaEval;

public abstract class CrossValidationEval
{
	CrossValidation xval;

	List<Evaluation> results[];

	public CrossValidationEval(MoleculeActivityData data, int numFolds, long randomSeed)
	{
		xval = new CrossValidation(data, numFolds, randomSeed);
	}

	public abstract TrainTestEvaluation getTrainTestEvaluation(int fold);

	@SuppressWarnings("unchecked")
	public void evaluate()
	{
		results = new List[xval.getNumFolds()];
		// for (int i = 0; i < xval.getNumFolds(); i++)
		// results[i] = getTrainTestEvaluation(i).evaluationResult();
	}

	public void printResults()
	{
		Status.INFO.println(this.getClass().getSimpleName() + " results: ");
		for (int i = 0; i < WekaEval.CLASSIFIERS.size(); i++)
		{
			Status.INFO.println("Classifier: " + WekaEval.CLASSIFIERS.get(i).getClass().getSimpleName());

			double avgAcc = 0;
			String acc = "";

			for (int j = 0; j < results.length; j++)
			{

				avgAcc = (avgAcc * j + results[j].get(i).pctCorrect()) / (double) (j + 1);

				if (j > 0)
					acc += ",";
				acc += StringUtil.formatDouble(results[j].get(i).pctCorrect());
			}

			Status.INFO.println(Status.TAB + "Accuracy: " + StringUtil.formatDouble(avgAcc) + " (" + acc + ")");
		}
	}
}
