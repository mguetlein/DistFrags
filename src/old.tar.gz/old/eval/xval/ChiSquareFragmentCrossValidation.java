package old.eval.xval;


public class ChiSquareFragmentCrossValidation // /extends FragmentCrossValidation
{

	// public ChiSquareFragmentCrossValidation(MoleculeActivityData data, int numFolds, long randomSeed)
	// {
	// super(data, numFolds, randomSeed);
	// }
	//
	// public FragmentMoleculeData generateTrainingFragments(MoleculeActivityData trainData)
	// {
	// FragmentMoleculeData fragments = super.generateTrainingFragments(trainData);
	// return FragmentFactory.applyChiSquareFilter(fragments, trainData);
	// }

}
