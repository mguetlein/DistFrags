package old.eval.xval;


public class DistancePairCrossValidation // extends CrossValidationEval
{

	// public DistancePairCrossValidation(MoleculeActivityData data, int numFolds, long randomSeed)
	// {
	// super(data, numFolds, randomSeed);
	// }
	//
	// public DistancePairData getTrainingDistancePairs(MoleculeActivityData trainData, FragmentMoleculeData fragments)
	// {
	// return DistancePairFactory.mineDistancePairs(trainData, fragments);
	// }
	//
	// @Override
	// public TrainTestEvaluation getTrainTestEvaluation(int fold)
	// {
	// MoleculeActivityData trainData = xval.getMoleculeActivityData(fold, false);
	// // FragmentMoleculeData fragments = FragmentFactory.mineFragments(trainData);
	// // DistancePairData distancePairs = getTrainingDistancePairs(trainData, fragments);
	// MoleculeActivityData testData = xval.getMoleculeActivityData(fold, true);
	//
	// return new DistancePairEvaluation(trainData, testData);
	// }

}
