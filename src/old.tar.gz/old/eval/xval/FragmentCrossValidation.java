package old.eval.xval;


public class FragmentCrossValidation // extends CrossValidationEval
{
	//
	// public FragmentCrossValidation(MoleculeActivityData data, int numFolds, long randomSeed)
	// {
	// super(data, numFolds, randomSeed);
	// }
	//
	// public FragmentMoleculeData generateTrainingFragments(MoleculeActivityData trainData)
	// {
	// return FragmentFactory.mineFragments(trainData);
	// }
	//
	// @Override
	// public TrainTestEvaluation getTrainTestEvaluation(int fold)
	// {
	// MoleculeActivityData trainData = xval.getMoleculeActivityData(fold, false);
	// // FragmentMoleculeData fragments = generateTrainingFragments(trainData);
	// MoleculeActivityData testData = xval.getMoleculeActivityData(fold, true);
	//
	// return new FragmentEvaluation(trainData, testData);
	// }
	//
}
