package old.eval.xval;


public class FStatisticsDistancePairCrossValidation // extends DistancePairCrossValidation
{

	// public FStatisticsDistancePairCrossValidation(MoleculeActivityData data, int numFolds, long randomSeed)
	// {
	// super(data, numFolds, randomSeed);
	// }
	//
	// @Override
	// public DistancePairData getTrainingDistancePairs(MoleculeActivityData trainData, FragmentMoleculeData fragments)
	// {
	// DistancePairData pairs = DistancePairFactory.mineDistancePairs(trainData, fragments);
	// return DistancePairFactory.applyFStatisticsFilter(pairs, trainData);
	// }

}
