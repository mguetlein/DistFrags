package old.eval.xval;


public class FragmentAndDistancePairCrossValidation // extends CrossValidationEval
{

	// public FragmentAndDistancePairCrossValidation(MoleculeActivityData data, int numFolds, long randomSeed)
	// {
	// super(data, numFolds, randomSeed);
	// }
	//
	// @Override
	// public TrainTestEvaluation getTrainTestEvaluation(int fold)
	// {
	// MoleculeActivityData trainData = xval.getMoleculeActivityData(fold, false);
	// // FragmentMoleculeData fragments = FragmentFactory.mineFragments(trainData);
	// // DistancePairData distancePairs = DistancePairFactory.mineDistancePairs(trainData, fragments);
	// MoleculeActivityData testData = xval.getMoleculeActivityData(fold, true);
	//
	// return new FragmentAndDistancePairEvaluation(trainData.getDatasetName(), testData.getDatasetName());
	// }

}
